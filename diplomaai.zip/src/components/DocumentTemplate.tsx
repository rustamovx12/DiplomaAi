import React from "react";
import { Award, Star, Compass, Heart, Shield, AwardIcon, Trophy, Sparkles, CheckCircle2 } from "lucide-react";

export type DocumentType = "diploma" | "certificate" | "gratitude";
export type DesignStyle = "classic" | "modern" | "gold" | "kids";

export interface DocumentTemplateProps {
  type: DocumentType;
  style: DesignStyle;
  variant?: number; // 1, 2, or 3 to trigger dynamic visual variations
  recipientName: string;
  topic?: string;
  teacherName: string;
  parentName?: string;
  reason?: string;
  signatureImage: string | null;
  date?: string;
  id?: string;
  serialNumber?: string;
  badgeType?: string; // e.g. "default", "excellence", "medal", "verified", "love"
  showQrCode?: boolean;
  qrCodeUrl?: string;
}

export default function DocumentTemplate({
  type,
  style,
  variant = 1,
  recipientName,
  topic = "",
  teacherName,
  parentName = "",
  reason = "",
  signatureImage,
  date = new Date().toLocaleDateString("uz-UZ", { year: "numeric", month: "long", day: "numeric" }),
  id = "print-certificate-target",
  serialNumber = "№ DA-2026-001",
  badgeType = "default",
  showQrCode = false,
  qrCodeUrl = ""
}: DocumentTemplateProps) {
  
  // Clean values for placeholder state
  const displayRecipient = recipientName.trim() || "[Ism Familiya]";
  const displayTopic = topic.trim() || "[Yo'nalish yoki Kurs mavzusi]";
  const displayTeacher = teacherName.trim() || "[Ustoz Ismi]";
  const displayParent = parentName.trim() || "[Ota-ona Ismi]";
  const displayReason = reason.trim() || "maktabimiz va darslarimizdagi faol ishtiroki hamda go'zal xulqi uchun Sizga chuqur minnatdorchiligimizni bildiramiz.";

  // Render Decorative Seal based on Choice and Variant
  const renderBadge = () => {
    // Determine icon based on badge selection
    let IconComponent = Award;
    let badgeText = "KAFOLATLANGAN";
    
    if (badgeType === "excellence") {
      IconComponent = Star;
      badgeText = "A'LO BAHOLIK";
    } else if (badgeType === "medal") {
      IconComponent = Trophy;
      badgeText = "MUVAFFAQIYAT";
    } else if (badgeType === "verified") {
      IconComponent = Shield;
      badgeText = "TASDIQLANGAN";
    } else if (badgeType === "love") {
      IconComponent = Heart;
      badgeText = "MINNATDORCHILIK";
    } else {
      // Default fallback matching the styles
      if (style === "classic") { IconComponent = Award; badgeText = "KAFOLAT"; }
      if (style === "gold") { IconComponent = Star; badgeText = "OLTIN MUHR"; }
      if (style === "modern") { IconComponent = Compass; badgeText = "SECURE GUID"; }
      if (style === "kids") { IconComponent = Trophy; badgeText = "ZO'RSIZ!"; }
    }

    // Styles for the Badge depending on design choices
    if (style === "classic") {
      const classicColors = [
        "bg-amber-600 border-amber-400 text-amber-100", // Variant 1 Goldish
        "bg-red-700 border-yellow-500 text-yellow-100", // Variant 2 Burgundy
        "bg-emerald-700 border-amber-500 text-amber-100" // Variant 3 Emerald
      ][(variant - 1) % 3];

      return (
        <div className="absolute left-1/2 -translate-x-1/2 bottom-14 flex flex-col items-center select-none">
          <div className="relative w-24 h-24 flex items-center justify-center">
            <div className={`absolute w-24 h-24 rounded-full opacity-25 animate-pulse bg-amber-500`}></div>
            <div className={`absolute w-20 h-20 rounded-full border-4 flex items-center justify-center shadow-xl ${classicColors}`}>
              <IconComponent className="w-10 h-10" />
            </div>
            {/* Double decorative ribbon tails */}
            <div className="absolute bottom-[-16px] left-5 w-5 h-12 bg-amber-600 transform rotate-12 -z-10 clip-path-ribbon opacity-90"></div>
            <div className="absolute bottom-[-16px] right-5 w-5 h-12 bg-amber-600 transform -rotate-12 -z-10 clip-path-ribbon opacity-90"></div>
          </div>
          <span className="text-[9px] font-bold text-amber-700 mt-6 tracking-widest font-classic uppercase">{badgeText}</span>
        </div>
      );
    }

    if (style === "gold") {
      const sealGradients = [
        "from-amber-400 via-yellow-200 to-amber-600 text-amber-950 border-amber-300",
        "from-yellow-300 via-amber-100 to-yellow-600 text-yellow-950 border-yellow-200",
        "from-orange-400 via-amber-200 to-amber-700 text-amber-950 border-amber-400"
      ][(variant - 1) % 3];

      return (
        <div className="absolute left-1/2 -translate-x-1/2 bottom-14 flex flex-col items-center select-none">
          <div className="relative w-24 h-24 flex items-center justify-center">
            <div className={`absolute w-22 h-22 rounded-full border-4 border-double bg-gradient-to-tr flex items-center justify-center shadow-2xl ${sealGradients}`}>
              <div className="absolute w-17 h-17 rounded-full border border-amber-950/20 flex flex-col items-center justify-center">
                <IconComponent className="w-8 h-8 fill-current opacity-80" />
                <span className="text-[7px] font-black mt-0.5 tracking-wider font-classic uppercase">{badgeText.split(" ")[0]}</span>
              </div>
            </div>
          </div>
          <span className="text-[9px] font-extrabold text-amber-800 mt-4 tracking-widest font-classic uppercase">PREMIUM CERTIFICATE</span>
        </div>
      );
    }

    if (style === "modern") {
      const modernStyles = [
        "from-cyan-500 to-indigo-600 text-white shadow-cyan-500/20",
        "from-fuchsia-500 to-purple-700 text-white shadow-fuchsia-500/20",
        "from-emerald-400 to-teal-600 text-white shadow-emerald-500/20"
      ][(variant - 1) % 3];

      return (
        <div className="absolute left-1/2 -translate-x-1/2 bottom-14 flex flex-col items-center select-none">
          <div className="relative w-22 h-22 flex items-center justify-center">
            <div className={`absolute w-20 h-20 rounded-2xl bg-gradient-to-tr rotate-45 shadow-lg flex items-center justify-center ${modernStyles}`}>
              <div className="-rotate-45 flex items-center justify-center">
                <IconComponent className="w-9 h-9" />
              </div>
            </div>
          </div>
          <span className="text-[9px] font-bold text-cyan-500 mt-5 tracking-widest font-modern uppercase">{badgeText}</span>
        </div>
      );
    }

    // Kids style playful badges
    const kidBadges = [
      "bg-yellow-400 border-white text-indigo-950 shadow-yellow-200",
      "bg-pink-400 border-white text-white shadow-pink-200",
      "bg-emerald-400 border-white text-indigo-950 shadow-emerald-200"
    ][(variant - 1) % 3];

    return (
      <div className="absolute left-1/2 -translate-x-1/2 bottom-14 flex flex-col items-center select-none">
        <div className="relative w-24 h-24 flex items-center justify-center">
          <div className={`absolute w-20 h-20 rounded-full border-4 border-dashed shadow-md flex items-center justify-center animate-bounce ${kidBadges}`}>
            <div className="flex flex-col items-center justify-center">
              <span className="text-xl">🏆</span>
              <span className="text-[9px] font-extrabold font-kids leading-none mt-0.5">{badgeText}</span>
            </div>
          </div>
        </div>
        <span className="text-[10px] font-black text-pink-500 mt-4 font-kids tracking-wide">DiplomaAI Kids</span>
      </div>
    );
  };

  // Get dynamic local Uzbek title
  const getDocTypeTitle = () => {
    if (type === "diploma") return "FAXRIY DIPLOM";
    if (type === "certificate") return "MALAKAVIY SERTIFIKAT";
    return "TASHAKKURNOMA";
  };

  // 1. CLASSIC THEME WITH 3 AMAZING VARIATIONS
  if (style === "classic") {
    // Variations: 1 = Imperial Navy Blue, 2 = Royal Burgundy Red, 3 = Academic Emerald Green
    const colors = [
      {
        border: "border-slate-900 bg-white",
        primaryText: "text-slate-900",
        accentText: "text-amber-600",
        divider: "bg-amber-500",
        innerBorder: "border-amber-500/80",
        corner: "border-amber-500",
        bodyBg: "bg-white",
        subtitleText: "text-slate-500",
        nameBorder: "border-amber-500/40"
      },
      {
        border: "border-[#4A0E17] bg-stone-50", // Royal Burgundy
        primaryText: "text-[#4A0E17]",
        accentText: "text-amber-700",
        divider: "bg-amber-600",
        innerBorder: "border-amber-600/70",
        corner: "border-amber-600",
        bodyBg: "bg-stone-50",
        subtitleText: "text-stone-600",
        nameBorder: "border-amber-600/40"
      },
      {
        border: "border-[#064E3B] bg-emerald-50/10", // Academic Emerald
        primaryText: "text-[#064E3B]",
        accentText: "text-amber-600",
        divider: "bg-amber-500",
        innerBorder: "border-amber-500/70",
        corner: "border-amber-500",
        bodyBg: "bg-white",
        subtitleText: "text-emerald-900/60",
        nameBorder: "border-amber-500/40"
      }
    ][(variant - 1) % 3];

    return (
      <div
        id={id}
        className={`relative w-[1000px] h-[707px] text-slate-900 border-[24px] shadow-2xl flex flex-col justify-between p-12 overflow-hidden select-none transition-all duration-300 ${colors.border}`}
      >
        {/* Inner classic thin border */}
        <div className={`absolute inset-2 border-2 pointer-events-none ${colors.innerBorder}`}></div>
        
        {/* Corner Flourishes */}
        <div className={`absolute top-4 left-4 w-12 h-12 border-t-4 border-l-4 ${colors.corner}`}></div>
        <div className={`absolute top-4 right-4 w-12 h-12 border-t-4 border-r-4 ${colors.corner}`}></div>
        <div className={`absolute bottom-4 left-4 w-12 h-12 border-b-4 border-l-4 ${colors.corner}`}></div>
        <div className={`absolute bottom-4 right-4 w-12 h-12 border-b-4 border-r-4 ${colors.corner}`}></div>

        {/* Top Header */}
        <div className="text-center mt-4">
          <div className="flex justify-center items-center gap-3 mb-1">
            <div className={`h-[1px] w-16 ${colors.divider}`}></div>
            <span className={`text-[10px] font-semibold tracking-[0.3em] font-classic ${colors.accentText}`}>DIPLOMAAI</span>
            <div className={`h-[1px] w-16 ${colors.divider}`}></div>
          </div>
          <h1 className={`text-[46px] font-extrabold tracking-wider font-classic mt-1 ${colors.primaryText}`}>
            {getDocTypeTitle()}
          </h1>
          {serialNumber && (
            <span className="text-[10px] font-mono tracking-widest text-slate-400 block mt-1">
              {serialNumber}
            </span>
          )}
        </div>

        {/* Content Body */}
        <div className="text-center px-14 my-auto flex flex-col justify-center">
          {type === "gratitude" ? (
            <>
              <p className={`font-serif italic text-base mb-1 ${colors.accentText}`}>Muhtaram Ota-ona:</p>
              <h2 className={`text-3xl font-extrabold font-classic tracking-wide mb-3 ${colors.primaryText}`}>
                {displayParent}
              </h2>
              <div className="w-12 h-[1px] bg-amber-400 mx-auto mb-3"></div>
              <p className={`text-[14px] leading-relaxed font-serif max-w-[720px] mx-auto text-slate-700`}>
                Sizning jondan aziz farzandingiz <strong className={`${colors.primaryText} font-sans text-[15px] font-bold`}>{displayRecipient}</strong> ning {displayReason}
              </p>
            </>
          ) : (
            <>
              <p className={`font-serif italic text-base mb-2 ${colors.subtitleText}`}>
                {type === "diploma" ? "Ushbu faxriy yorliq tantanali ravishda topshiriladi:" : "Ushbu malakaviy sertifikat taqdim etiladi:"}
              </p>
              <h2 className={`text-4xl font-extrabold font-serif tracking-normal border-b pb-2 inline-block mx-auto min-w-[340px] mb-3 ${colors.primaryText} ${colors.nameBorder}`}>
                {displayRecipient}
              </h2>
              <p className="text-[11px] uppercase tracking-widest text-slate-400 font-sans mb-1">
                {type === "diploma" ? "Erishgan yutuqlari va yo'nalishi:" : "Kurs / Fan yo'nalishi:"}
              </p>
              <p className={`text-xl font-bold font-classic tracking-wide max-w-[760px] mx-auto leading-snug ${colors.accentText}`}>
                {displayTopic}
              </p>
            </>
          )}
        </div>

        {/* Bottom Metadata & Signatures */}
        <div className="grid grid-cols-3 items-end px-6 mb-2">
          {/* Left: Date & QR */}
          <div className="text-left flex items-end gap-3">
            {showQrCode && (
              <div className="flex flex-col items-center gap-1 shrink-0">
                <div className={`p-1 bg-white border rounded-md ${colors.corner ? colors.corner.replace('border-t-4', '').replace('border-l-4', '').replace('border-b-4', '').replace('border-r-4', '') : 'border-slate-300'}`}>
                  <img
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=70x70&data=${encodeURIComponent(qrCodeUrl)}`}
                    alt="QR Code"
                    className="w-12 h-12 object-contain"
                    referrerPolicy="no-referrer"
                    crossOrigin="anonymous"
                  />
                </div>
                <span className="text-[7px] text-slate-400 font-mono tracking-widest uppercase">TEKSHIRISH</span>
              </div>
            )}
            <div>
              <p className="text-[9px] uppercase tracking-wider text-slate-400 font-sans">Berilgan sana</p>
              <p className="text-sm font-semibold text-slate-800 font-serif border-t border-slate-300 pt-1 mt-1 inline-block">
                {date}
              </p>
            </div>
          </div>

          {/* Center: Decorative seal spacing */}
          <div className="flex justify-center h-12"></div>

          {/* Right: Signature */}
          <div className="text-right flex flex-col items-end relative">
            {signatureImage && (
              <img
                src={signatureImage}
                alt="Signature"
                className="absolute bottom-6 right-8 h-15 object-contain pointer-events-none filter brightness-90"
              />
            )}
            <p className="text-[9px] uppercase tracking-wider text-slate-400 font-sans">Mas'ul shaxs / Ustoz</p>
            <p className={`text-sm font-bold font-serif border-t border-slate-300 pt-1 mt-1 inline-block min-w-[160px] ${colors.primaryText}`}>
              {displayTeacher}
            </p>
          </div>
        </div>

        {/* Render Seal */}
        {renderBadge()}
      </div>
    );
  }

  // 2. GOLD PREMIUM THEME WITH 3 AMAZING VARIATIONS
  if (style === "gold") {
    // Variations: 1 = Golden Royalty, 2 = Champagne Ivory & Gold, 3 = Antique Bronze & Gold
    const colors = [
      {
        gradient: "from-amber-50 via-yellow-50/40 to-amber-100/30",
        border: "border-amber-950",
        innerLine: "border-amber-400",
        primaryText: "text-amber-950",
        accentText: "text-amber-800",
        badgeGlow: "bg-amber-500",
        watermarkOpacity: "opacity-[0.03]"
      },
      {
        gradient: "from-stone-50 via-[#FAF9F6] to-[#F5F2EB]", // Champagne Ivory
        border: "border-[#403121]", // Luxury Chocolate Gold
        innerLine: "border-amber-500/80",
        primaryText: "text-[#2B1E10]",
        accentText: "text-amber-700",
        badgeGlow: "bg-yellow-400",
        watermarkOpacity: "opacity-[0.04]"
      },
      {
        gradient: "from-amber-100/40 via-yellow-100/20 to-orange-100/30", // Antique Bronze Warmth
        border: "border-[#542F07]", // Deep Bronze Border
        innerLine: "border-amber-600",
        primaryText: "text-[#3D1D02]",
        accentText: "text-amber-800",
        badgeGlow: "bg-orange-500",
        watermarkOpacity: "opacity-[0.02]"
      }
    ][(variant - 1) % 3];

    return (
      <div
        id={id}
        className={`relative w-[1000px] h-[707px] text-slate-900 border-[24px] shadow-2xl flex flex-col justify-between p-12 overflow-hidden select-none transition-all duration-300 bg-gradient-to-br ${colors.gradient} ${colors.border}`}
      >
        {/* Layered luxury borders */}
        <div className={`absolute inset-1 border-[3px] pointer-events-none ${colors.innerLine}`}></div>
        <div className="absolute inset-3 border border-amber-300/40 pointer-events-none"></div>
        <div className="absolute inset-5 border-[2px] border-amber-500/20 pointer-events-none"></div>

        {/* Golden corner flourishes */}
        <div className="absolute top-6 left-6 w-16 h-16 border-t-4 border-l-4 border-amber-400/80 rounded-tl-lg"></div>
        <div className="absolute top-6 right-6 w-16 h-16 border-t-4 border-r-4 border-amber-400/80 rounded-tr-lg"></div>
        <div className="absolute bottom-6 left-6 w-16 h-16 border-b-4 border-l-4 border-amber-400/80 rounded-bl-lg"></div>
        <div className="absolute bottom-6 right-6 w-16 h-16 border-b-4 border-r-4 border-amber-400/80 rounded-br-lg"></div>

        {/* Seal Watermark backdrop */}
        <div className={`absolute inset-0 pointer-events-none flex items-center justify-center ${colors.watermarkOpacity}`}>
          <div className="w-[520px] h-[520px] rounded-full border-[20px] border-amber-600 flex items-center justify-center">
            <Award className="w-[320px] h-[320px]" />
          </div>
        </div>

        {/* Top Header */}
        <div className="text-center mt-4 relative z-10">
          <div className="flex justify-center items-center gap-3 mb-1">
            <span className="text-[9px] font-extrabold tracking-[0.45em] font-serif text-amber-800">PREMIUM ROYAL SELECTION</span>
          </div>
          <h1 className="text-5xl font-black tracking-wide font-classic drop-shadow-xs mt-1 bg-gradient-to-r from-amber-950 via-amber-800 to-amber-950 bg-clip-text text-transparent">
            {getDocTypeTitle()}
          </h1>
          <div className="w-52 h-[1px] bg-gradient-to-r from-transparent via-amber-500 to-transparent mx-auto mt-2.5"></div>
          {serialNumber && (
            <span className="text-[10px] font-mono tracking-widest text-amber-800/60 block mt-1.5 font-bold">
              {serialNumber}
            </span>
          )}
        </div>

        {/* Content Body */}
        <div className="text-center px-12 my-auto flex flex-col justify-center relative z-10">
          {type === "gratitude" ? (
            <>
              <p className={`font-serif italic text-base font-semibold mb-1 ${colors.accentText}`}>Yuksak ehtirom ila taqdim etiladi, Muhtaram Ota-ona:</p>
              <h2 className={`text-3xl font-black font-classic tracking-wider mb-3 drop-shadow-xs ${colors.primaryText}`}>
                {displayParent}
              </h2>
              <p className="text-[13px] text-amber-950/90 max-w-[710px] mx-auto leading-relaxed font-serif px-6 bg-white/50 py-3.5 rounded-xl border border-amber-200/40 backdrop-blur-xs">
                Sizning barcha maktab jamoasi hurmatini qozongan o'g'il-qizingiz <strong className={`${colors.primaryText} font-sans text-base font-black`}>{displayRecipient}</strong> ning darslardagi tinimsiz intilishi, yuksak odob-axloqi hamda bilim olishga bo'lgan cheksiz ishtiyoqi uchun Sizga chuqur minnatdorchilik bildiramiz!
              </p>
            </>
          ) : (
            <>
              <p className={`font-serif italic text-base font-medium mb-1.5 ${colors.accentText}`}>
                {type === "diploma" ? "Yuksak natijalar va a'lo intizom uchun ushbu diplom topshiriladi:" : "Kursni muvaffaqiyatli yakunlaganlik tasdig'i sifatida beriladi:"}
              </p>
              <h2 className="text-4xl font-black font-classic tracking-wider border-b-2 border-amber-300 pb-2 inline-block mx-auto min-w-[340px] mb-3 bg-gradient-to-r from-amber-950 via-amber-800 to-amber-950 bg-clip-text text-transparent">
                {displayRecipient}
              </h2>
              <p className="text-[10px] text-amber-700 uppercase tracking-widest font-sans font-bold mb-1">
                {type === "diploma" ? "Zafar quchgan yo'nalishi:" : "Kurs / Muvaffaqiyat yo'nalishi:"}
              </p>
              <p className={`text-[22px] font-extrabold font-serif tracking-wide max-w-[760px] mx-auto leading-snug ${colors.primaryText}`}>
                « {displayTopic} »
              </p>
            </>
          )}
        </div>

        {/* Bottom Metadata & Signatures */}
        <div className="grid grid-cols-3 items-end px-6 mb-2 relative z-10">
          {/* Left: Date & QR */}
          <div className="text-left flex items-end gap-3">
            {showQrCode && (
              <div className="flex flex-col items-center gap-1 shrink-0">
                <div className="p-1 bg-white border border-amber-400 rounded-md">
                  <img
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=70x70&data=${encodeURIComponent(qrCodeUrl)}`}
                    alt="QR Code"
                    className="w-12 h-12 object-contain"
                    referrerPolicy="no-referrer"
                    crossOrigin="anonymous"
                  />
                </div>
                <span className="text-[7px] text-amber-800/80 font-mono tracking-widest uppercase font-bold">TEKSHIRISH</span>
              </div>
            )}
            <div>
              <p className="text-[9px] uppercase tracking-wider text-amber-800 font-sans font-bold">Berilgan Sana</p>
              <p className={`text-sm font-bold font-serif border-t-2 border-amber-300 pt-1 mt-1 inline-block ${colors.primaryText}`}>
                {date}
              </p>
            </div>
          </div>

          {/* Center: Seal Space */}
          <div className="flex justify-center h-12"></div>

          {/* Right: Signature */}
          <div className="text-right flex flex-col items-end relative">
            {signatureImage && (
              <img
                src={signatureImage}
                alt="Signature"
                className="absolute bottom-6 right-8 h-17 object-contain pointer-events-none filter brightness-95"
              />
            )}
            <p className="text-[9px] uppercase tracking-wider text-amber-800 font-sans font-bold">Bosh Ustoz / Direktor</p>
            <p className={`text-sm font-black font-serif border-t-2 border-amber-300 pt-1 mt-1 inline-block min-w-[170px] ${colors.primaryText}`}>
              {displayTeacher}
            </p>
          </div>
        </div>

        {/* Royal Seal */}
        {renderBadge()}
      </div>
    );
  }

  // 3. MODERN DIGITAL THEME WITH 3 AMAZING VARIATIONS
  if (style === "modern") {
    // Variations: 1 = Cyber Cyan & Indigo, 2 = Purple Nebula, 3 = Matrix Emerald
    const colors = [
      {
        gradient: "bg-slate-950 text-white",
        glows: (
          <>
            <div className="absolute -top-40 -left-40 w-96 h-96 bg-cyan-500 rounded-full blur-[140px] opacity-25"></div>
            <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-indigo-600 rounded-full blur-[140px] opacity-35"></div>
          </>
        ),
        gridColor: "bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)]",
        lineColor: "border-slate-800/80",
        accentText: "text-cyan-400",
        accentGlow: "bg-cyan-500",
        primaryText: "text-white",
        subText: "text-slate-400"
      },
      {
        gradient: "bg-[#090514] text-white", // Dark Violet Nebula
        glows: (
          <>
            <div className="absolute -top-40 -left-40 w-96 h-96 bg-fuchsia-600 rounded-full blur-[140px] opacity-20"></div>
            <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-purple-700 rounded-full blur-[140px] opacity-30"></div>
          </>
        ),
        gridColor: "bg-[linear-gradient(to_right,#2e1065_1px,transparent_1px),linear-gradient(to_bottom,#2e1065_1px,transparent_1px)]",
        lineColor: "border-purple-950",
        accentText: "text-fuchsia-400",
        accentGlow: "bg-fuchsia-500",
        primaryText: "text-white",
        subText: "text-slate-300"
      },
      {
        gradient: "bg-slate-950 text-white", // Matte Carbon & Mint Green
        glows: (
          <>
            <div className="absolute -top-40 -left-40 w-96 h-96 bg-emerald-500 rounded-full blur-[150px] opacity-15"></div>
            <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-teal-600 rounded-full blur-[140px] opacity-25"></div>
          </>
        ),
        gridColor: "bg-[linear-gradient(to_right,#064e3b_1px,transparent_1px),linear-gradient(to_bottom,#064e3b_1px,transparent_1px)]",
        lineColor: "border-emerald-950/80",
        accentText: "text-emerald-400",
        accentGlow: "bg-emerald-500",
        primaryText: "text-white",
        subText: "text-slate-400"
      }
    ][(variant - 1) % 3];

    return (
      <div
        id={id}
        className={`relative w-[1000px] h-[707px] border-[20px] border-slate-900 shadow-2xl flex flex-col justify-between p-12 overflow-hidden select-none transition-all duration-300 ${colors.gradient}`}
      >
        {/* Dynamic futuristic grid overlay */}
        <div className={`absolute inset-0 bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-30 ${colors.gridColor}`}></div>
        
        {/* Render respective glows */}
        {colors.glows}

        {/* Minimalist framing */}
        <div className={`absolute inset-4 border pointer-events-none ${colors.lineColor}`}></div>
        <div className="absolute inset-6 border border-slate-800/20 pointer-events-none"></div>
        
        {/* Top Header */}
        <div className="text-center mt-4 relative z-10">
          <span className={`text-[9px] font-bold tracking-[0.55em] font-modern uppercase ${colors.accentText}`}>DIPLOMAAI FUTURE INNOVATION</span>
          <h1 className="text-5xl font-black tracking-tight font-modern mt-2 bg-gradient-to-r from-white via-slate-200 to-cyan-100 bg-clip-text text-transparent">
            {getDocTypeTitle()}
          </h1>
          <div className={`h-1 w-24 mx-auto mt-3 rounded-full ${colors.accentGlow}`}></div>
          {serialNumber && (
            <span className="text-[10px] font-mono tracking-widest text-slate-500 block mt-2 font-bold">
              ID-HASH: {serialNumber}
            </span>
          )}
        </div>

        {/* Content Body */}
        <div className="text-center px-12 my-auto flex flex-col justify-center relative z-10">
          {type === "gratitude" ? (
            <>
              <p className={`font-modern text-xs tracking-widest uppercase mb-1.5 ${colors.accentText}`}>HURMATLI VALIDE_YN:</p>
              <h2 className="text-4xl font-extrabold text-white font-modern tracking-tight mb-3">
                {displayParent}
              </h2>
              <div className="text-slate-300 max-w-[700px] mx-auto leading-relaxed font-sans text-sm bg-slate-950/60 p-4 rounded-2xl border border-slate-800 backdrop-blur-md">
                Sizning farzandingiz <strong className={`${colors.accentText} font-medium`}>{displayRecipient}</strong> o'zining darslardagi tinimsiz intilishi, yuksak intellektual salohiyati hamda zamonaviy bilimlarni egallashdagi faolligi bilan barchaga o'rnak bo'ldi. Farzandingizga bergan munosib tarbiyangiz uchun chuqur minnatdorchilik bildiramiz!
              </div>
            </>
          ) : (
            <>
              <p className="text-slate-400 font-modern text-[10px] tracking-widest uppercase mb-2">
                {type === "diploma" ? "DIPLOM EGACHI:" : "SERTIFIKAT SOHIBI:"}
              </p>
              <h2 className="text-4xl font-black text-white font-modern tracking-tight mb-3 bg-gradient-to-r from-white via-slate-300 to-indigo-100 bg-clip-text text-transparent">
                {displayRecipient}
              </h2>
              <div className="w-16 h-[1px] bg-slate-800 mx-auto mb-3"></div>
              <p className="text-[10px] text-slate-500 uppercase tracking-widest font-modern mb-1">
                {type === "diploma" ? "Yo'nalish / Maxsus yutuq:" : "Kurs / Sertifikatsiyalangan mavzu:"}
              </p>
              <p className={`text-2xl font-bold font-modern tracking-wide max-w-[760px] mx-auto leading-snug ${colors.accentText}`}>
                {displayTopic}
              </p>
            </>
          )}
        </div>

        {/* Bottom Metadata & Signatures */}
        <div className="grid grid-cols-3 items-end px-6 mb-2 relative z-10">
          {/* Left: Date & QR */}
          <div className="text-left flex items-end gap-3">
            {showQrCode && (
              <div className="flex flex-col items-center gap-1 shrink-0">
                <div className={`p-1 bg-white border rounded-md ${colors.lineColor}`}>
                  <img
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=70x70&data=${encodeURIComponent(qrCodeUrl)}`}
                    alt="QR Code"
                    className="w-12 h-12 object-contain"
                    referrerPolicy="no-referrer"
                    crossOrigin="anonymous"
                  />
                </div>
                <span className="text-[7px] text-slate-500 font-mono tracking-widest uppercase font-bold">VERIFY</span>
              </div>
            )}
            <div>
              <p className="text-[9px] uppercase tracking-widest text-slate-500 font-modern">Taqdim Etilgan Sana</p>
              <p className="text-sm font-semibold text-slate-200 font-modern border-t border-slate-800 pt-1 mt-1 inline-block">
                {date}
              </p>
            </div>
          </div>

          {/* Center: Seal space */}
          <div className="flex justify-center h-12"></div>

          {/* Right: Signature */}
          <div className="text-right flex flex-col items-end relative">
            {signatureImage && (
              <img
                src={signatureImage}
                alt="Signature"
                className="absolute bottom-6 right-8 h-14 object-contain pointer-events-none filter invert contrast-125 brightness-110"
              />
            )}
            <p className="text-[9px] uppercase tracking-widest text-slate-500 font-modern">Mentor / Kordinator</p>
            <p className={`text-sm font-semibold font-modern border-t border-slate-800 pt-1 mt-1 inline-block min-w-[150px] ${colors.accentText}`}>
              {displayTeacher}
            </p>
          </div>
        </div>

        {/* Cyber Seal */}
        {renderBadge()}
      </div>
    );
  }

  // 4. KIDS PLAYFUL THEME WITH 3 AMAZING VARIATIONS
  // Variations: 1 = Sky Cloud Blue, 2 = Soft Lavender/Pink Candy, 3 = Sunny Safari Mint Green
  const colorsKids = [
    {
      bg: "bg-sky-50 text-indigo-900",
      dotPattern: "bg-[radial-gradient(#fed7aa_1.5px,transparent_1.5px)]",
      border: "border-amber-400",
      badgePill: "bg-indigo-100/80 text-indigo-700 border-indigo-200",
      emojiLeft: "🎈", emojiRight: "🌟", emojiBotLeft: "✨", emojiBotRight: "🧸",
      recipientText: "text-indigo-900 bg-white/70",
      recipientBorder: "border-indigo-200",
      accentText: "text-orange-500"
    },
    {
      bg: "bg-[#FFF0F5] text-purple-950", // Lavender / Pink
      dotPattern: "bg-[radial-gradient(#fbcfe8_1.5px,transparent_1.5px)]",
      border: "border-pink-400",
      badgePill: "bg-pink-100/80 text-pink-700 border-pink-200",
      emojiLeft: "🍭", emojiRight: "🦄", emojiBotLeft: "🌸", emojiBotRight: "😻",
      recipientText: "text-purple-900 bg-white/80",
      recipientBorder: "border-pink-200",
      accentText: "text-pink-500"
    },
    {
      bg: "bg-[#F0FFF4] text-emerald-950", // Mint Safari
      dotPattern: "bg-[radial-gradient(#bbf7d0_1.5px,transparent_1.5px)]",
      border: "border-emerald-400",
      badgePill: "bg-emerald-100/80 text-emerald-700 border-emerald-200",
      emojiLeft: "🦁", emojiRight: "🍍", emojiBotLeft: "🌴", emojiBotRight: "🦖",
      recipientText: "text-emerald-900 bg-white/80",
      recipientBorder: "border-emerald-200",
      accentText: "text-emerald-500"
    }
  ][(variant - 1) % 3];

  return (
    <div
      id={id}
      className={`relative w-[1000px] h-[707px] border-[20px] shadow-2xl flex flex-col justify-between p-12 overflow-hidden select-none font-kids transition-all duration-300 ${colorsKids.bg} ${colorsKids.border}`}
    >
      {/* Playful dots overlay */}
      <div className={`absolute inset-0 [background-size:16px_16px] opacity-40 ${colorsKids.dotPattern}`}></div>

      {/* Playful borders */}
      <div className="absolute inset-3 border-4 border-dashed border-white rounded-2xl pointer-events-none"></div>
      <div className="absolute inset-5 border-2 border-indigo-200/40 rounded-xl pointer-events-none"></div>

      {/* Floating emojis based on sub-variant choice */}
      <div className="absolute top-6 left-6 text-3xl animate-bounce duration-700">{colorsKids.emojiLeft}</div>
      <div className="absolute top-6 right-6 text-3xl animate-pulse">{colorsKids.emojiRight}</div>
      <div className="absolute bottom-6 left-6 text-3xl animate-pulse">{colorsKids.emojiBotLeft}</div>
      <div className="absolute bottom-6 right-6 text-3xl animate-bounce duration-1000">{colorsKids.emojiBotRight}</div>

      {/* Top Header */}
      <div className="text-center mt-4 relative z-10">
        <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold mb-1 border ${colorsKids.badgePill}`}>
          ⭐ DIPLOMAAI BOLALAR MUKOFOTI ⭐
        </div>
        <h1 className="text-5xl font-black text-indigo-900 tracking-wide font-kids mt-2 drop-shadow-[0_2px_0_rgba(255,255,255,1)]">
          {getDocTypeTitle()}
        </h1>
        {serialNumber && (
          <span className="text-[10px] text-indigo-400 block mt-1">
            Serial: {serialNumber}
          </span>
        )}
      </div>

      {/* Content Body */}
      <div className="text-center px-12 my-auto flex flex-col justify-center relative z-10">
        {type === "gratitude" ? (
          <>
            <p className="text-pink-500 text-lg font-bold mb-1">Mehribon va Jonkuyar Ota-onajonlar:</p>
            <h2 className={`text-3xl font-extrabold tracking-wide mb-3 py-1.5 px-6 rounded-full inline-block mx-auto border shadow-sm ${colorsKids.recipientText} ${colorsKids.recipientBorder}`}>
              {displayParent}
            </h2>
            <p className="text-base text-slate-700 max-w-[700px] mx-auto leading-relaxed px-6 py-3 bg-white/80 rounded-2xl shadow-sm border border-orange-100 font-sans">
              Sizning aqlli, tirishqoq va intizomli farzandingiz <strong className={`${colorsKids.accentText} font-black text-lg`}>{displayRecipient}</strong> ning darslardagi ajoyib ishtiroki va namunali xulqi uchun Sizga katta rahmat aytamiz! Hamisha farzandingiz kamolini ko'rib quvonib yuringlar! 🎉
            </p>
          </>
        ) : (
          <>
            <p className={`text-base font-bold mb-2 ${colorsKids.accentText}`}>
              {type === "diploma" ? "Ushbu quvnoq va ajoyib mukofot topshiriladi:" : "Kursda muvaffaqiyatli qatnashgani uchun beriladi:"}
            </p>
            <h2 className="text-4xl font-extrabold text-indigo-900 tracking-wide mb-4 bg-white px-8 py-2 rounded-full border-4 border-dashed border-indigo-200 inline-block mx-auto shadow-md transform -rotate-1">
              {displayRecipient}
            </h2>
            <p className="text-[11px] text-orange-400 uppercase tracking-widest mb-1 font-sans font-bold">
              {type === "diploma" ? "Erishgan eng ajoyib yutug'i / ishi:" : "Kursda o'rgangan bilim mavzusi:"}
            </p>
            <p className="text-2xl font-black text-indigo-800 tracking-wide max-w-[750px] mx-auto leading-snug">
              🌟 {displayTopic} 🌟
            </p>
          </>
        )}
      </div>

      {/* Bottom Metadata & Signatures */}
      <div className="grid grid-cols-3 items-end px-6 mb-2 relative z-10">
        {/* Left: Date & QR */}
        <div className="text-left flex items-end gap-3">
          {showQrCode && (
            <div className="flex flex-col items-center gap-1 shrink-0">
              <div className="p-1 bg-white border-2 border-dashed border-indigo-200 rounded-md">
                <img
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=70x70&data=${encodeURIComponent(qrCodeUrl)}`}
                  alt="QR Code"
                  className="w-12 h-12 object-contain"
                  referrerPolicy="no-referrer"
                  crossOrigin="anonymous"
                />
              </div>
              <span className="text-[7px] text-indigo-400 font-mono font-black uppercase">TEKSHIRISH</span>
            </div>
          )}
          <div>
            <p className="text-[9px] uppercase text-indigo-400">Berilgan Sana</p>
            <p className="text-sm font-bold text-indigo-900 border-t-2 border-indigo-200 pt-1 mt-1 inline-block">
              {date}
            </p>
          </div>
        </div>

        {/* Center: Seal space */}
        <div className="flex justify-center h-12"></div>

        {/* Right: Signature */}
        <div className="text-right flex flex-col items-end relative">
          {signatureImage && (
            <img
              src={signatureImage}
              alt="Signature"
              className="absolute bottom-5 right-8 h-14 object-contain pointer-events-none transform rotate-3"
            />
          )}
          <p className="text-[9px] uppercase text-indigo-400">Ustoz / Murabbiy</p>
          <p className="text-sm font-bold text-indigo-900 border-t-2 border-indigo-200 pt-1 mt-1 inline-block min-w-[150px]">
            {displayTeacher}
          </p>
        </div>
      </div>

      {/* Kids Reward Badge */}
      {renderBadge()}
    </div>
  );
}
