import React, { useState, useEffect, useRef } from "react";
import { 
  Award, 
  FileText, 
  Heart, 
  ChevronLeft, 
  Printer, 
  Download, 
  RotateCcw, 
  User, 
  BookOpen, 
  Sparkles, 
  FileCheck, 
  Home, 
  CheckCircle2, 
  AlertCircle,
  PenTool,
  Palette,
  Shield,
  Trophy,
  Star,
  Settings,
  Music,
  Volume2,
  VolumeX,
  Play,
  Pause,
  SkipForward,
  Sun,
  Moon,
  QrCode
} from "lucide-react";
import html2canvas from "html2canvas-pro";
import SignatureCanvas from "./components/SignatureCanvas";
import DocumentTemplate, { DocumentType, DesignStyle } from "./components/DocumentTemplate";

export default function App() {
  // Music Player state and audio element reference
  const tracks = [
    { name: "Tinchlantiruvchi Pianino", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3" },
    { name: "Focus Ambient Musik", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3" },
    { name: "Ijodiy Lofi Chill", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3" },
    { name: "Klassik Simfoniya", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3" }
  ];
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.3);
  const [isMuted, setIsMuted] = useState(false);
  const [showPlayerPanel, setShowPlayerPanel] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Initialize audio ref
  useEffect(() => {
    audioRef.current = new Audio(tracks[currentTrackIndex].url);
    audioRef.current.loop = true;
    audioRef.current.volume = isMuted ? 0 : volume;

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  // Sync track change
  useEffect(() => {
    if (audioRef.current) {
      const playingBefore = isPlaying;
      audioRef.current.pause();
      audioRef.current.src = tracks[currentTrackIndex].url;
      audioRef.current.load();
      if (playingBefore) {
        audioRef.current.play().catch((e) => console.log("Audio play prevented:", e));
      }
    }
  }, [currentTrackIndex]);

  // Sync play/pause state
  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.play().catch((e) => {
          console.log("Audio play prevented, resetting isPlaying:", e);
          setIsPlaying(false);
        });
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying]);

  // Sync volume & mute
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume;
    }
  }, [volume, isMuted]);

  // Splash Screen status
  const [showSplash, setShowSplash] = useState(true);

  // Dark/Light Mode state
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const saved = localStorage.getItem("theme");
    if (saved) return saved === "dark";
    return window.matchMedia("(prefers-color-scheme: dark)").matches;
  });

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  }, [isDarkMode]);
  
  // Navigation states
  const [currentScreen, setCurrentScreen] = useState<"menu" | "form" | "result">("menu");
  const [selectedType, setSelectedType] = useState<DocumentType | null>(null);

  // Form states
  const [recipientName, setRecipientName] = useState("");
  const [topic, setTopic] = useState("");
  const [teacherName, setTeacherName] = useState("");
  const [parentName, setParentName] = useState("");
  const [reason, setReason] = useState("");
  const [designStyle, setDesignStyle] = useState<DesignStyle>("classic");
  const [variant, setVariant] = useState<number>(1);
  const [badgeType, setBadgeType] = useState<string>("default");
  const [serialNumber, setSerialNumber] = useState("");
  const [signatureImage, setSignatureImage] = useState<string | null>(null);
  const [showQrCode, setShowQrCode] = useState(true);
  const [qrCodeUrl, setQrCodeUrl] = useState(() => {
    return typeof window !== "undefined" ? window.location.href : "";
  });
  const [showQrModal, setShowQrModal] = useState(false);
  
  // Date state (defaults to today in Uzbek style)
  const [customDate, setCustomDate] = useState(() => {
    return new Date().toLocaleDateString("uz-UZ", { 
      year: "numeric", 
      month: "long", 
      day: "numeric" 
    });
  });

  // Validation errors
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  // Document generation state (committed on form submit)
  const [generatedDoc, setGeneratedDoc] = useState<{
    type: DocumentType;
    style: DesignStyle;
    variant: number;
    recipientName: string;
    topic: string;
    teacherName: string;
    parentName: string;
    reason: string;
    signatureImage: string | null;
    date: string;
    serialNumber: string;
    badgeType: string;
    showQrCode: boolean;
    qrCodeUrl: string;
  } | null>(null);

  // Success toast state
  const [showToast, setShowToast] = useState(false);
  
  // Exporter/Downloader Loading state
  const [isDownloading, setIsDownloading] = useState(false);

  // Modal fallback for iframe blocked downloads
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [downloadedImageUri, setDownloadedImageUri] = useState<string | null>(null);

  // Responsive scale factor for certificate preview container
  const previewContainerRef = useRef<HTMLDivElement | null>(null);
  const [scaleFactor, setScaleFactor] = useState(1);

  // Auto-expire Splash Screen after 2 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  // Recalculate scaling factor for the preview component
  useEffect(() => {
    const handleResize = () => {
      if (previewContainerRef.current) {
        const containerWidth = previewContainerRef.current.clientWidth;
        // The certificate's native width is 1000px.
        // We scale it dynamically to perfectly fit the wrapper layout.
        const factor = Math.min((containerWidth - 24) / 1000, 1.0);
        setScaleFactor(factor > 0 ? factor : 0.8);
      }
    };

    // Run once after DOM rendering or screen change
    if (currentScreen === "result" || currentScreen === "form") {
      setTimeout(handleResize, 100);
    }

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [currentScreen, selectedType]);

  // Handle Category Choice
  const handleSelectCategory = (type: DocumentType) => {
    setSelectedType(type);
    
    // Reset form fields
    setRecipientName("");
    setTopic("");
    setTeacherName("");
    setParentName("");
    setReason("");
    setSignatureImage(null);
    setDesignStyle("classic");
    setVariant(1);
    setBadgeType("default");
    setShowQrCode(true);
    setQrCodeUrl(typeof window !== "undefined" ? window.location.href : "");
    
    // Generate beautiful custom serial number
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    const prefix = type === "diploma" ? "DP" : type === "certificate" ? "SR" : "TN";
    setSerialNumber(`№ ${prefix}-${randomNum}-2026`);
    
    setErrors({});
    
    // Set typical template/preset if applicable
    if (type === "gratitude") {
      setReason(
        "maktabimiz va darslarimizdagi faol ishtiroki, chiroyli odobi hamda intizomi bilan boshqalarga o'rnak bo'lgani uchun Sizga o'z minnatdorchiligimizni bildiramiz. Kelajakda bundanda ulkan zafarlar tilaymiz!"
      );
    }
    
    setCurrentScreen("form");
  };

  // Pre-configured Tashakkurnoma reasons templates
  const applyTashakkurTemplate = (index: number) => {
    if (index === 1) {
      setReason("maktabimiz va darslarimizdagi faol ishtiroki, chiroyli odobi hamda intizomi bilan boshqalarga o'rnak bo'lgani uchun Sizga o'z minnatdorchiligimizni bildiramiz. Kelajakda bundanda ulkan zafarlar tilaymiz!");
    } else if (index === 2) {
      setReason("darslarga mas'uliyat bilan yondashgani, barcha topshiriqlarni o'z vaqtida a'lo baholarga bajargani va yuksak tirishqoqligi bilan ajralib turgani uchun Sizdek tarbiyachi ota-onaga chuqur rahmat aytamiz.");
    } else if (index === 3) {
      setReason("guruhimizdagi o'zaro do'stona muhitni rivojlantirishga qo'shgan hissasi, g'oyat samimiy xulqi va ustozlariga bo'lgan cheksiz hurmati bilan barchaning mehrini qozongani uchun minnatdorchilik bildiramiz.");
    }
  };

  // Cycle Variant Action in Result Screen (Dynamic design changes instantly!)
  const handleCycleVariant = () => {
    const nextVariant = variant === 3 ? 1 : variant + 1;
    setVariant(nextVariant);
    if (generatedDoc) {
      setGeneratedDoc(prev => prev ? { ...prev, variant: nextVariant } : null);
    }
  };

  // Cycle Style directly on Result stage
  const handleCycleStyle = (styleName: DesignStyle) => {
    setDesignStyle(styleName);
    if (generatedDoc) {
      setGeneratedDoc(prev => prev ? { ...prev, style: styleName } : null);
    }
  };

  // Perform Form Validation
  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!recipientName.trim()) {
      newErrors.recipientName = selectedType === "gratitude" ? "O‘quvchi ismini kiriting" : "Ism va familiyani kiriting";
    }

    if (selectedType !== "gratitude" && !topic.trim()) {
      newErrors.topic = selectedType === "diploma" ? "Yo‘nalish yoki yutuqni kiriting" : "Sertifikat mavzusini kiriting";
    }

    if (selectedType === "gratitude" && !parentName.trim()) {
      newErrors.parentName = "Ota-ona ismini kiriting";
    }

    if (selectedType === "gratitude" && !reason.trim()) {
      newErrors.reason = "Tashakkurnoma sababini kiriting";
    }

    if (!teacherName.trim()) {
      newErrors.teacherName = "Ustoz ismini kiriting";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Submit Form & Go to Result View
  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) {
      // Scroll to top of errors
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }

    // Save configuration
    setGeneratedDoc({
      type: selectedType!,
      style: designStyle,
      variant: variant,
      recipientName,
      topic,
      teacherName,
      parentName,
      reason,
      signatureImage,
      date: customDate,
      serialNumber,
      badgeType,
      showQrCode,
      qrCodeUrl: qrCodeUrl.trim() || (typeof window !== "undefined" ? window.location.href : "")
    });

    setCurrentScreen("result");
    setShowToast(true);
    setTimeout(() => {
      setShowToast(false);
    }, 4000);
  };

  // Trigger Native Browser Print Action
  const handlePrint = () => {
    window.print();
  };

  // Helper to parse and convert OKLCH and OKLAB color strings into standard RGB/RGBA strings
  const convertOklToRgbString = (colorStr: string): string => {
    if (!colorStr) return colorStr;
    
    const normalized = colorStr.trim();
    
    return normalized.replace(/(oklch|oklab)\(([^)]+)\)/gi, (match, type, inner) => {
      try {
        const cleanedInner = inner.replace(/[,/]/g, " ").trim();
        const parts = cleanedInner.split(/\s+/);
        
        if (parts.length < 3) return match;
        
        const L_str = parts[0];
        let L = parseFloat(L_str);
        if (L_str.endsWith("%")) {
          L = parseFloat(L_str) / 100;
        }
        
        const p2_str = parts[1];
        let p2 = parseFloat(p2_str);
        if (p2_str.endsWith("%")) {
          p2 = (parseFloat(p2_str) / 100) * 0.4;
        }
        
        const p3_str = parts[2];
        let p3 = parseFloat(p3_str);
        if (type.toLowerCase() === "oklch") {
          if (p3_str.endsWith("rad")) {
            p3 = parseFloat(p3_str) * (180 / Math.PI);
          } else if (p3_str.endsWith("grad")) {
            p3 = parseFloat(p3_str) * 0.9;
          } else if (p3_str.endsWith("turn")) {
            p3 = parseFloat(p3_str) * 360;
          } else {
            p3 = parseFloat(p3_str);
          }
        } else {
          if (p3_str.endsWith("%")) {
            p3 = (parseFloat(p3_str) / 100) * 0.4;
          }
        }
        
        let alpha = 1;
        if (parts.length >= 4) {
          const alpha_str = parts[3];
          alpha = parseFloat(alpha_str);
          if (alpha_str.endsWith("%")) {
            alpha = parseFloat(alpha_str) / 100;
          }
        }
        
        let r, g, b_;
        if (type.toLowerCase() === "oklch") {
          const hueRad = p3 * (Math.PI / 180);
          const a = p2 * Math.cos(hueRad);
          const b = p2 * Math.sin(hueRad);
          
          const l_ = L + 0.3963377774 * a + 0.2158037573 * b;
          const m_ = L - 0.1055613458 * a - 0.0638541728 * b;
          const s_ = L - 0.0894841775 * a - 1.2914855480 * b;

          const l = l_ * l_ * l_;
          const m = m_ * m_ * m_;
          const s = s_ * s_ * s_;

          r = +4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s;
          g = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s;
          b_ = -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s;
        } else {
          const a = p2;
          const b = p3;
          
          const l_ = L + 0.3963377774 * a + 0.2158037573 * b;
          const m_ = L - 0.1055613458 * a - 0.0638541728 * b;
          const s_ = L - 0.0894841775 * a - 1.2914855480 * b;

          const l = l_ * l_ * l_;
          const m = m_ * m_ * m_;
          const s = s_ * s_ * s_;

          r = +4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s;
          g = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s;
          b_ = -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s;
        }
        
        const f = (c: number) => c <= 0.0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055;
        
        const R = Math.max(0, Math.min(255, Math.round(f(r) * 255)));
        const G = Math.max(0, Math.min(255, Math.round(f(g) * 255)));
        const B = Math.max(0, Math.min(255, Math.round(f(b_) * 255)));
        
        if (alpha === 1) {
          return `rgb(${R}, ${G}, ${B})`;
        } else {
          return `rgba(${R}, ${G}, ${B}, ${alpha})`;
        }
      } catch (e) {
        console.warn("Failed to convert color:", match, e);
        return match;
      }
    });
  };

  // Helper to recursively map and style cloned elements using original elements' computed styles
  const applyComputedStylesToClone = (original: HTMLElement, clone: HTMLElement) => {
    const computed = window.getComputedStyle(original);
    
    const propertiesToFix = [
      "color",
      "backgroundColor",
      "borderColor",
      "borderTopColor",
      "borderRightColor",
      "borderBottomColor",
      "borderLeftColor",
      "outlineColor",
      "textDecorationColor",
      "fill",
      "stroke"
    ];
    
    propertiesToFix.forEach((prop) => {
      const val = computed[prop as any];
      if (val && (val.includes("oklch") || val.includes("oklab"))) {
        const fixedVal = convertOklToRgbString(val);
        clone.style[prop as any] = fixedVal;
      }
    });
    
    const originalChildren = Array.from(original.children);
    const cloneChildren = Array.from(clone.children);
    
    for (let i = 0; i < originalChildren.length; i++) {
      if (cloneChildren[i]) {
        applyComputedStylesToClone(originalChildren[i] as HTMLElement, cloneChildren[i] as HTMLElement);
      }
    }
  };

  // Download high-resolution PNG using html2canvas
  const handleDownload = async () => {
    const target = document.getElementById("print-certificate-target");
    if (!target) {
      console.error("Print target element not found");
      return;
    }

    const disabledSheets: any[] = [];
    let tempStyleNode: HTMLStyleElement | null = null;
    let customClone: HTMLElement | null = null;

    try {
      setIsDownloading(true);

      // 1. Compile all style rules and clean oklch/oklab
      let combinedCss = "";
      for (let i = 0; i < document.styleSheets.length; i++) {
        const sheet = document.styleSheets[i];
        try {
          const rules = sheet.cssRules || sheet.rules;
          if (rules) {
            for (let j = 0; j < rules.length; j++) {
              combinedCss += rules[j].cssText + "\n";
            }
          }
        } catch (e) {
          if (sheet.ownerNode && sheet.ownerNode.textContent) {
            combinedCss += sheet.ownerNode.textContent + "\n";
          }
        }
      }

      const cleanedCss = convertOklToRgbString(combinedCss);

      // 2. Inject temporary clean stylesheet
      tempStyleNode = document.createElement("style");
      tempStyleNode.id = "html2canvas-temp-clean-styles";
      tempStyleNode.textContent = cleanedCss;
      document.head.appendChild(tempStyleNode);

      // 3. Disable original stylesheets
      for (let i = 0; i < document.styleSheets.length; i++) {
        const sheet = document.styleSheets[i];
        if (sheet && sheet.ownerNode && sheet.ownerNode !== tempStyleNode) {
          try {
            (sheet as any).disabled = true;
            disabledSheets.push(sheet);
          } catch (e) {
            // ignore
          }
        }
      }

      // 4. Create custom clone of the target with absolute off-screen positioning
      customClone = target.cloneNode(true) as HTMLElement;
      customClone.id = "print-certificate-target-clone";
      customClone.style.position = "absolute";
      customClone.style.left = "-9999px";
      customClone.style.top = "-9999px";
      customClone.style.width = target.offsetWidth + "px";
      customClone.style.height = target.offsetHeight + "px";
      customClone.style.margin = "0";
      customClone.style.padding = "12mm"; // Match original index.css target padding
      customClone.style.boxShadow = "none";
      customClone.style.background = "white";
      document.body.appendChild(customClone);

      // 5. Convert every computed style of original to inline RGB/RGBA on the custom clone
      applyComputedStylesToClone(target, customClone);

      // We set scale to 2 for sharp retina resolution (2000px width).
      const canvas = await html2canvas(customClone, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: null,
        logging: false,
        onclone: (clonedDoc) => {
          // Additional safety cleanup inside html2canvas's own iframe sandbox
          const styleTags = clonedDoc.getElementsByTagName("style");
          for (let i = 0; i < styleTags.length; i++) {
            const style = styleTags[i];
            if (style.innerHTML) {
              style.innerHTML = convertOklToRgbString(style.innerHTML);
            }
          }

          const allElements = clonedDoc.getElementsByTagName("*");
          for (let i = 0; i < allElements.length; i++) {
            const el = allElements[i] as HTMLElement;
            if (el.style && el.style.cssText) {
              el.style.cssText = convertOklToRgbString(el.style.cssText);
            }
          }
        }
      });

      const dataUrl = canvas.toDataURL("image/png");
      setDownloadedImageUri(dataUrl);
      setShowSaveModal(true);

      // Attempt automatic download by appending to document body first (more reliable in frames)
      const filename = `DiplomaAI-${recipientName.trim().replace(/\s+/g, "_") || "hujjat"}.png`;
      const link = document.createElement("a");
      link.download = filename;
      link.href = dataUrl;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error("Hujjatni yuklab olishda xatolik yuz berdi:", err);
    } finally {
      // 6. Clean up temporary clone and restore original stylesheets
      if (customClone && customClone.parentNode) {
        customClone.parentNode.removeChild(customClone);
      }

      disabledSheets.forEach((sheet) => {
        try {
          sheet.disabled = false;
        } catch (e) {
          // ignore
        }
      });

      if (tempStyleNode && tempStyleNode.parentNode) {
        tempStyleNode.parentNode.removeChild(tempStyleNode);
      }

      setIsDownloading(false);
    }
  };

  // Reset and return back to menu
  const handleRestart = () => {
    setCurrentScreen("menu");
    setSelectedType(null);
  };

  // Get localized sub-variant label based on currently chosen style
  const getVariantLabel = (vNum: number) => {
    if (designStyle === "classic") {
      if (vNum === 1) return "Imperator To'q Ko'k (Navy)";
      if (vNum === 2) return "Qirollik Burgundiyasi (Wine)";
      return "Akademik Zumrad (Forest Green)";
    }
    if (designStyle === "gold") {
      if (vNum === 1) return "Zarhal Oltin (Gold Royalty)";
      if (vNum === 2) return "Champagne Ivory (Oq va Oltin)";
      return "Antik Bronza (Bronze Warmth)";
    }
    if (designStyle === "modern") {
      if (vNum === 1) return "Kiber Kian (Cyan Neon Grid)";
      if (vNum === 2) return "Binafsha Tuman (Purple Aurora)";
      return "Minimalist Yalpiz (Emerald Carbon)";
    }
    // Kids style
    if (vNum === 1) return "Moviy Bulutlar (Sky Blue)";
    if (vNum === 2) return "Pushti Konfet (Sweet Pink Candy)";
    return "Safari O'rmon (Jungle Green)";
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors duration-300">
      
      {/* 1. SPLASH SCREEN */}
      {showSplash && (
        <div className="fixed inset-0 bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-950 z-50 flex flex-col items-center justify-center p-6 text-center animate-fade-in">
          {/* Glowing Animated Circle Decoration */}
          <div className="absolute w-[450px] h-[450px] rounded-full bg-indigo-500/10 blur-[100px] pointer-events-none"></div>
          <div className="absolute w-[250px] h-[250px] rounded-full bg-amber-500/5 blur-[80px] pointer-events-none"></div>

          <div className="relative z-10 flex flex-col items-center">
            {/* Elegant Trophy Badge with glow animation */}
            <div className="w-24 h-24 bg-amber-500/10 border-2 border-amber-400 rounded-full flex items-center justify-center mb-6 pulse-glow">
              <Award className="w-12 h-12 text-amber-400" />
            </div>
            
            <h1 className="text-5xl md:text-7xl font-black text-white tracking-tight mb-3 font-classic bg-gradient-to-r from-amber-200 via-yellow-100 to-amber-300 bg-clip-text text-transparent">
              DiplomaAI
            </h1>
            
            <div className="w-20 h-1 bg-gradient-to-r from-amber-500 to-yellow-300 rounded-full mb-8"></div>
            
            <p className="text-slate-400 text-sm tracking-widest uppercase mb-1">
              Aqlli Diplom, Sertifikat va Tashakkurnoma Yaratuvchi
            </p>
            <p className="text-amber-400/90 text-sm font-medium italic mt-2">
              Asoschi: Muhammadaziz Rustamov
            </p>
          </div>
        </div>
      )}

      {/* 2. NAVIGATION BAR */}
      <header className="no-print bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 sticky top-0 z-30 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-amber-500 rounded-xl flex items-center justify-center text-white shadow-md shadow-amber-500/20">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <span className="text-lg font-extrabold tracking-tight bg-gradient-to-r from-slate-900 via-indigo-950 to-amber-600 dark:from-white dark:to-amber-400 bg-clip-text text-transparent font-classic">
                DiplomaAI
              </span>
              <span className="hidden sm:inline-block text-[10px] bg-amber-100 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 px-1.5 py-0.5 rounded-md font-bold ml-2">
                v1.5 PRO
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {currentScreen !== "menu" && (
              <button
                onClick={handleRestart}
                className="inline-flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white transition-colors cursor-pointer px-3 py-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <Home className="w-4 h-4" /> Bosh sahifa
              </button>
            )}

            {/* QR Code Utility Toggle */}
            <button
              onClick={() => setShowQrModal(true)}
              title="Mobil telefonda ishlatish"
              className="inline-flex items-center gap-1.5 text-xs bg-amber-500/10 hover:bg-amber-500/20 text-amber-700 dark:text-amber-400 font-bold transition-all cursor-pointer px-3 py-1.5 rounded-lg border border-amber-500/20"
            >
              <QrCode className="w-4 h-4 text-amber-500" /> 
              <span>Mobil ilova</span>
            </button>

            {/* Dark Mode Toggle */}
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              title={isDarkMode ? "Yorug' rejimga o'tish" : "Qorong'u rejimga o'tish"}
              className="p-2 text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white transition-colors cursor-pointer rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center border border-slate-200 dark:border-slate-700"
            >
              {isDarkMode ? (
                <Sun className="w-4 h-4 text-amber-500" />
              ) : (
                <Moon className="w-4 h-4 text-slate-600" />
              )}
            </button>

            <div className="hidden md:flex items-center text-xs text-slate-400 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700">
              <span className="w-2 h-2 rounded-full bg-emerald-500 mr-2 animate-pulse"></span>
              Siz bilan: Muhammadaziz Rustamov
            </div>
          </div>
        </div>
      </header>

      {/* MAIN LAYOUT */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col justify-center">
        
        {/* SUCCESS TOAST ALERT */}
        {showToast && (
          <div className="no-print fixed top-20 right-4 z-40 bg-emerald-600 text-white px-5 py-3 rounded-xl shadow-2xl flex items-center gap-3 animate-slide-up border border-emerald-500">
            <CheckCircle2 className="w-5 h-5 text-emerald-100 shrink-0" />
            <div>
              <p className="font-bold text-sm">Tabriklaymiz!</p>
              <p className="text-xs text-emerald-100">Hujjat a'lo darajada shakllantirildi.</p>
            </div>
          </div>
        )}

        {/* SCREEN A: CATEGORY MENU */}
        {currentScreen === "menu" && (
          <div className="space-y-12 py-6 animate-fade-in">
            {/* Title Block */}
            <div className="text-center max-w-2xl mx-auto space-y-4">
              <div className="inline-flex items-center gap-1.5 bg-amber-500/10 text-amber-700 dark:text-amber-400 px-3 py-1 rounded-full text-xs font-bold tracking-wide border border-amber-500/20">
                <Sparkles className="w-3.5 h-3.5" /> 7 yoshdan 70 yoshgacha oson foydalanish
              </div>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-slate-900 dark:text-white font-classic tracking-tight">
                Qaysi hujjatni yaratmoqchisiz?
              </h2>
              <p className="text-slate-500 dark:text-slate-400 text-sm sm:text-base">
                Mavjud andozalar ustida cheksiz dizayn variatsiyalari va ranglar uyg'unligi bilan mutlaqo takrorlanmas natijaga erishing!
              </p>
            </div>

            {/* Selection Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8 max-w-5xl mx-auto">
              
              {/* Card 1: DIPLOMA */}
              <div
                onClick={() => handleSelectCategory("diploma")}
                className="group relative bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-8 hover:border-amber-500 dark:hover:border-amber-500 shadow-lg hover:shadow-2xl transition-all duration-300 cursor-pointer text-center flex flex-col justify-between overflow-hidden"
              >
                {/* Visual hover glow effect */}
                <div className="absolute top-0 inset-x-0 h-1.5 bg-amber-500 group-hover:h-3 transition-all"></div>
                <div className="absolute -top-12 -right-12 w-24 h-24 bg-amber-500/5 group-hover:bg-amber-500/10 rounded-full transition-colors"></div>
                
                <div className="space-y-5 my-4">
                  <div className="w-16 h-16 bg-amber-500/10 border border-amber-400 rounded-2xl flex items-center justify-center mx-auto group-hover:scale-110 transition-transform">
                    <span className="text-3xl">🏆</span>
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white font-classic">
                      Diplom yaratish
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                      Musobaqalar, tanlovlar yoki a'lo baholarga tamomlagan o'quvchilar uchun rasmiy faxriy diplom tayyorlang.
                    </p>
                  </div>
                </div>

                <div className="mt-6">
                  <span className="inline-flex items-center gap-1 text-xs font-bold text-amber-600 dark:text-amber-400 group-hover:translate-x-1 transition-transform">
                    Hozir yaratish &rarr;
                  </span>
                </div>
              </div>

              {/* Card 2: CERTIFICATE */}
              <div
                onClick={() => handleSelectCategory("certificate")}
                className="group relative bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-8 hover:border-indigo-500 dark:hover:border-indigo-500 shadow-lg hover:shadow-2xl transition-all duration-300 cursor-pointer text-center flex flex-col justify-between overflow-hidden"
              >
                {/* Visual hover glow effect */}
                <div className="absolute top-0 inset-x-0 h-1.5 bg-indigo-500 group-hover:h-3 transition-all"></div>
                <div className="absolute -top-12 -right-12 w-24 h-24 bg-indigo-500/5 group-hover:bg-indigo-500/10 rounded-full transition-colors"></div>

                <div className="space-y-5 my-4">
                  <div className="w-16 h-16 bg-indigo-500/10 border border-indigo-400 rounded-2xl flex items-center justify-center mx-auto group-hover:scale-110 transition-transform">
                    <span className="text-3xl">📜</span>
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white font-classic">
                      Sertifikat yaratish
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                      Kurslar, master-klasslar, darslar yoki ilmiy seminarlar tamomlangani munosabati bilan rasmiy sertifikat.
                    </p>
                  </div>
                </div>

                <div className="mt-6">
                  <span className="inline-flex items-center gap-1 text-xs font-bold text-indigo-600 dark:text-indigo-400 group-hover:translate-x-1 transition-transform">
                    Hozir yaratish &rarr;
                  </span>
                </div>
              </div>

              {/* Card 3: TASHAKKURNOMA */}
              <div
                onClick={() => handleSelectCategory("gratitude")}
                className="group relative bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-8 hover:border-rose-500 dark:hover:border-rose-500 shadow-lg hover:shadow-2xl transition-all duration-300 cursor-pointer text-center flex flex-col justify-between overflow-hidden"
              >
                {/* Visual hover glow effect */}
                <div className="absolute top-0 inset-x-0 h-1.5 bg-rose-500 group-hover:h-3 transition-all"></div>
                <div className="absolute -top-12 -right-12 w-24 h-24 bg-rose-500/5 group-hover:bg-rose-500/10 rounded-full transition-colors"></div>

                <div className="space-y-5 my-4">
                  <div className="w-16 h-16 bg-rose-500/10 border border-rose-400 rounded-2xl flex items-center justify-center mx-auto group-hover:scale-110 transition-transform">
                    <span className="text-3xl">❤️</span>
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white font-classic">
                      Ota-onaga tashakkurnoma
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                      Farzandini a'lo tarbiyalagan, darslarida qo'llab-quvvatlagan mehribon ota-onalarga chuqur minnatdorchilik xati.
                    </p>
                  </div>
                </div>

                <div className="mt-6">
                  <span className="inline-flex items-center gap-1 text-xs font-bold text-rose-600 dark:text-rose-400 group-hover:translate-x-1 transition-transform">
                    Hozir yaratish &rarr;
                  </span>
                </div>
              </div>

            </div>

            {/* Quick Informational Guide */}
            <div className="max-w-3xl mx-auto bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left">
              <span className="text-3xl">💡</span>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                <strong>DiplomaAI farqi nimada?</strong> Har bir dizayn uslubi o'z ichida 3 xil yuqori sifatli vizual ko'rinishga (variantga) ega. Agar birinchisi yoqmasa, tugmani bitta bosish orqali boshqa rang palitralari va ramkalarini sinab ko'rishingiz mumkin. Mutlaqo universal va mukammal!
              </p>
            </div>
          </div>
        )}

        {/* SCREEN B: FORM BUILDER */}
        {currentScreen === "form" && selectedType && (
          <div className="space-y-8 animate-fade-in">
            {/* Header / Back Action */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setCurrentScreen("menu")}
                  className="p-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                  title="Orqaga qaytish"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <div>
                  <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white font-classic">
                    {selectedType === "diploma" && "🏆 Diplom ma'lumotlarini to'ldiring"}
                    {selectedType === "certificate" && "📜 Sertifikat ma'lumotlarini to'ldiring"}
                    {selectedType === "gratitude" && "❤️ Tashakkurnoma ma'lumotlarini to'ldiring"}
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Ma'lumotlarni kiriting va dizayn uslublarini tanlang (imzo qo'yish ixtiyoriy)
                  </p>
                </div>
              </div>

              {/* Status Indicator */}
              <div className="self-start sm:self-center flex items-center gap-2 px-3 py-1 bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 rounded-full text-xs font-bold border border-amber-200 dark:border-amber-900">
                <PenTool className="w-3.5 h-3.5" /> Bosqichma-bosqich shakllantirish
              </div>
            </div>

            {/* Split Form & Mini-Preview Layout */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* Form Side - occupying 7 cols */}
              <form onSubmit={handleGenerate} className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 shadow-md border border-slate-200 dark:border-slate-800 space-y-6">
                
                {/* Form Field Errors Alert */}
                {Object.keys(errors).length > 0 && (
                  <div className="bg-rose-50 dark:bg-rose-950/20 text-rose-700 dark:text-rose-400 p-4 rounded-2xl text-xs flex items-start gap-2.5 border border-rose-100 dark:border-rose-900">
                    <AlertCircle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold">Iltimos, xatoliklarni to'g'rilang:</p>
                      <ul className="list-disc list-inside mt-1 space-y-0.5 font-medium">
                        {Object.values(errors).map((err, i) => (
                          <li key={i}>{err}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}

                <div className="space-y-4">
                  {/* Field: Recipient Name (For all types) */}
                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1.5">
                      <User className="w-4 h-4 text-slate-400" />
                      {selectedType === "gratitude" ? "O'quvchi ismi familiyasi" : "Kimga beriladi (Ism va Familiya)"} <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={recipientName}
                      onChange={(e) => {
                        setRecipientName(e.target.value);
                        if (errors.recipientName) setErrors(prev => ({ ...prev, recipientName: "" }));
                      }}
                      placeholder={selectedType === "gratitude" ? "Masalan: Madina Rustamova" : "Masalan: Sardor Toshpulatov"}
                      className={`w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border-2 rounded-xl text-sm focus:outline-none focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-950 transition-colors ${errors.recipientName ? "border-rose-400" : "border-slate-200 dark:border-slate-700"}`}
                    />
                  </div>

                  {/* Field: Parent Name (ONLY for gratitude) */}
                  {selectedType === "gratitude" && (
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1.5">
                        <Heart className="w-4 h-4 text-slate-400" />
                        Ota-ona ismi (Kimga yo'llanadi) <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={parentName}
                        onChange={(e) => {
                          setParentName(e.target.value);
                          if (errors.parentName) setErrors(prev => ({ ...prev, parentName: "" }));
                        }}
                        placeholder="Masalan: Shuxratbek va Lolaxon Rustamovlar"
                        className={`w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border-2 rounded-xl text-sm focus:outline-none focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-950 transition-colors ${errors.parentName ? "border-rose-400" : "border-slate-200 dark:border-slate-700"}`}
                      />
                    </div>
                  )}

                  {/* Field: Topic (ONLY for diploma & certificate) */}
                  {selectedType !== "gratitude" && (
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1.5">
                        <BookOpen className="w-4 h-4 text-slate-400" />
                        {selectedType === "diploma" ? "Yo'nalish / Nima bo'yicha yutuq" : "Sertifikat mavzusi / Kurs nomi"} <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={topic}
                        onChange={(e) => {
                          setTopic(e.target.value);
                          if (errors.topic) setErrors(prev => ({ ...prev, topic: "" }));
                        }}
                        placeholder={selectedType === "diploma" ? "Masalan: Matematika fan olimpiadasi 1-o'rin sohibi" : "Masalan: Zamonaviy Frontend (React & Tailwind) kursi"}
                        className={`w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border-2 rounded-xl text-sm focus:outline-none focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-950 transition-colors ${errors.topic ? "border-rose-400" : "border-slate-200 dark:border-slate-700"}`}
                      />
                    </div>
                  )}

                  {/* Field: Reason with templates (ONLY for gratitude) */}
                  {selectedType === "gratitude" && (
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                          Tashakkurnoma matni (sababi) <span className="text-red-500">*</span>
                        </label>
                        <span className="text-[10px] text-slate-400">Pastdan tayyor andozalarni tanlashingiz mumkin</span>
                      </div>
                      <textarea
                        value={reason}
                        onChange={(e) => {
                          setReason(e.target.value);
                          if (errors.reason) setErrors(prev => ({ ...prev, reason: "" }));
                        }}
                        rows={4}
                        placeholder="Nima uchun tashakkurnoma berilishi sababini yozing..."
                        className={`w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border-2 rounded-xl text-sm focus:outline-none focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-950 transition-colors leading-relaxed ${errors.reason ? "border-rose-400" : "border-slate-200 dark:border-slate-700"}`}
                      />
                      {/* Templates shortcuts */}
                      <div className="flex flex-wrap gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => applyTashakkurTemplate(1)}
                          className="text-[10px] bg-slate-100 dark:bg-slate-800 hover:bg-rose-50 dark:hover:bg-rose-950/20 text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 font-medium transition-all cursor-pointer"
                        >
                          ✨ Andoza 1: Odob va intizom
                        </button>
                        <button
                          type="button"
                          onClick={() => applyTashakkurTemplate(2)}
                          className="text-[10px] bg-slate-100 dark:bg-slate-800 hover:bg-rose-50 dark:hover:bg-rose-950/20 text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 font-medium transition-all cursor-pointer"
                        >
                          📚 Andoza 2: A'lo o'qish
                        </button>
                        <button
                          type="button"
                          onClick={() => applyTashakkurTemplate(3)}
                          className="text-[10px] bg-slate-100 dark:bg-slate-800 hover:bg-rose-50 dark:hover:bg-rose-950/20 text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 font-medium transition-all cursor-pointer"
                        >
                          🌟 Andoza 3: Faollik & Tirishqoqlik
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Row: Teacher name & Serial number */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1.5">
                        <User className="w-4 h-4 text-slate-400" />
                        Tasdiqlovchi shaxs / Ustoz <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={teacherName}
                        onChange={(e) => {
                          setTeacherName(e.target.value);
                          if (errors.teacherName) setErrors(prev => ({ ...prev, teacherName: "" }));
                        }}
                        placeholder="Masalan: Muhammadaziz Rustamov"
                        className={`w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border-2 rounded-xl text-sm focus:outline-none focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-950 transition-colors ${errors.teacherName ? "border-rose-400" : "border-slate-200 dark:border-slate-700"}`}
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1.5">
                        <Settings className="w-4 h-4 text-slate-400" />
                        Seriya raqami
                      </label>
                      <input
                        type="text"
                        value={serialNumber}
                        onChange={(e) => setSerialNumber(e.target.value)}
                        className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 rounded-xl text-sm focus:outline-none focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-950 transition-colors"
                      />
                    </div>
                  </div>

                  {/* Grid: Date & Badge selection */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                        Berilgan sana
                      </label>
                      <input
                        type="text"
                        value={customDate}
                        onChange={(e) => setCustomDate(e.target.value)}
                        className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 rounded-xl text-sm focus:outline-none focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-950 transition-colors"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                        Dekorativ Muhr / Badge turi
                      </label>
                      <select
                        value={badgeType}
                        onChange={(e) => setBadgeType(e.target.value)}
                        className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 rounded-xl text-sm focus:outline-none focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-950 transition-colors"
                      >
                        <option value="default">Uslubga mos (Standart)</option>
                        <option value="excellence">⭐ A'lo Baho (Yulduzli muhr)</option>
                        <option value="medal">🏆 Muvaffaqiyat (Oltin Kubok)</option>
                        <option value="verified">🛡️ Tasdiqlangan (Qalqonli muhr)</option>
                        <option value="love">❤️ Minnatdorchilik (Yurakli muhr)</option>
                      </select>
                    </div>
                  </div>

                  {/* Field: Signature drawing canvas with touch support */}
                  <div className="pt-2">
                    <SignatureCanvas 
                      onSave={(dataUrl) => {
                        setSignatureImage(dataUrl);
                        if (dataUrl && errors.signature) {
                          setErrors(prev => ({ ...prev, signature: "" }));
                        }
                      }}
                      defaultValue={signatureImage}
                    />
                    {errors.signature && (
                      <p className="text-rose-500 text-xs mt-1 font-medium">{errors.signature}</p>
                    )}
                  </div>

                  {/* Field: Premium Style Design Selection */}
                  <div className="pt-4 space-y-3">
                    <label className="block text-sm font-bold text-slate-900 dark:text-white font-classic">
                      Dizayn uslubini tanlang
                    </label>
                    <div className="grid grid-cols-2 gap-3 sm:gap-4">
                      
                      {/* Classic Style select card */}
                      <div
                        onClick={() => {
                          setDesignStyle("classic");
                          setVariant(1);
                        }}
                        className={`cursor-pointer border-2 rounded-2xl p-4 flex flex-col justify-between transition-all ${designStyle === "classic" ? "border-slate-900 dark:border-white bg-slate-50 dark:bg-slate-800 ring-2 ring-indigo-500/10" : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/30"}`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-slate-900 dark:text-white font-classic">Klassik</span>
                          <span className="w-4 h-4 rounded-full border border-slate-400 flex items-center justify-center p-0.5">
                            {designStyle === "classic" && <span className="w-2.5 h-2.5 bg-indigo-600 dark:bg-white rounded-full"></span>}
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-500 mt-2">
                          Imperial Navy to'q ko'k, Royal Burgundy va Akademik Zumrad ranglari.
                        </p>
                      </div>

                      {/* Gold Premium Style card */}
                      <div
                        onClick={() => {
                          setDesignStyle("gold");
                          setVariant(1);
                        }}
                        className={`cursor-pointer border-2 rounded-2xl p-4 flex flex-col justify-between transition-all ${designStyle === "gold" ? "border-amber-500 bg-amber-500/5 ring-2 ring-amber-500/10" : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/30"}`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-amber-800 dark:text-amber-400 font-classic">Qirollik Oltini</span>
                          <span className="w-4 h-4 rounded-full border border-amber-400 flex items-center justify-center p-0.5">
                            {designStyle === "gold" && <span className="w-2.5 h-2.5 bg-amber-500 rounded-full"></span>}
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-500 mt-2">
                          Zarhal tilla, Champagne Ivory va antiqiy bronza elementlari uyg'unligi.
                        </p>
                      </div>

                      {/* Modern Digital Style card */}
                      <div
                        onClick={() => {
                          setDesignStyle("modern");
                          setVariant(1);
                        }}
                        className={`cursor-pointer border-2 rounded-2xl p-4 flex flex-col justify-between transition-all ${designStyle === "modern" ? "border-cyan-500 bg-cyan-500/5 ring-2 ring-cyan-500/10" : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/30"}`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-cyan-500 font-modern">Zamonaviy</span>
                          <span className="w-4 h-4 rounded-full border border-cyan-400 flex items-center justify-center p-0.5">
                            {designStyle === "modern" && <span className="w-2.5 h-2.5 bg-cyan-500 rounded-full"></span>}
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-500 mt-2">
                          Minimalist va neon chiziqli kiber, binafsha va yalpizli to'q qorong'u foni.
                        </p>
                      </div>

                      {/* Kids Style card */}
                      <div
                        onClick={() => {
                          setDesignStyle("kids");
                          setVariant(1);
                        }}
                        className={`cursor-pointer border-2 rounded-2xl p-4 flex flex-col justify-between transition-all ${designStyle === "kids" ? "border-yellow-400 bg-yellow-400/5 ring-2 ring-yellow-400/10" : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/30"}`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-indigo-700 dark:text-indigo-400 font-kids">Bolalar uchun</span>
                          <span className="w-4 h-4 rounded-full border border-yellow-400 flex items-center justify-center p-0.5">
                            {designStyle === "kids" && <span className="w-2.5 h-2.5 bg-yellow-400 rounded-full"></span>}
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-500 mt-2">
                          Moviy osmon, shirin pushti va safari tropik yashil quvnoq ranglar.
                        </p>
                      </div>

                    </div>
                  </div>

                  {/* Sub-variant Selector in the Form (Interactive design check) */}
                  <div className="pt-2 space-y-2">
                    <label className="text-xs font-bold text-slate-800 dark:text-slate-300 flex items-center gap-1.5">
                      <Palette className="w-3.5 h-3.5 text-indigo-500" /> Rang va Uslub Variatsiyasi
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {[1, 2, 3].map((vNum) => (
                        <button
                          key={vNum}
                          type="button"
                          onClick={() => setVariant(vNum)}
                          className={`py-2 px-3 text-xs rounded-xl font-medium transition-all cursor-pointer border ${variant === vNum ? "bg-indigo-600 border-indigo-600 text-white shadow-sm" : "bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700"}`}
                        >
                          Variant {vNum}
                        </button>
                      ))}
                    </div>
                    <p className="text-[10px] text-slate-500">
                      Hozirgi tanlov: <strong className="text-slate-700 dark:text-slate-300">{getVariantLabel(variant)}</strong>
                    </p>
                  </div>

                  {/* Field: QR Code Option */}
                  <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <QrCode className="w-4 h-4 text-indigo-500" />
                        <span className="text-xs font-bold text-slate-900 dark:text-white font-classic">Hujjatga QR-kod joylash</span>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer select-none">
                        <input
                          type="checkbox"
                          checked={showQrCode}
                          onChange={(e) => setShowQrCode(e.target.checked)}
                          className="sr-only peer"
                        />
                        <div className="w-9 h-5 bg-slate-200 dark:bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
                      </label>
                    </div>
                    {showQrCode && (
                      <div className="space-y-1.5 animate-fade-in pl-6">
                        <label className="block text-[10px] font-medium text-slate-500">
                          QR kod havolasi (Bo'sh qolsa, loyiha manzili olinadi):
                        </label>
                        <input
                          type="text"
                          value={qrCodeUrl}
                          onChange={(e) => setQrCodeUrl(e.target.value)}
                          placeholder="Masalan: https://loyiha.uz"
                          className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-950 transition-colors"
                        />
                      </div>
                    )}
                  </div>

                </div>

                {/* Create/Generate Trigger */}
                <div className="pt-4">
                  <button
                    type="submit"
                    className="w-full bg-gradient-to-r from-amber-500 via-amber-600 to-indigo-600 text-white font-extrabold py-4 px-6 rounded-2xl shadow-lg hover:shadow-indigo-500/20 transform hover:-translate-y-0.5 transition-all text-sm tracking-wide flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <FileCheck className="w-5 h-5" /> HUJJATNI SHAKLLANTIRISH
                  </button>
                </div>

              </form>

              {/* LIVE PREVIEW SIDE - occupying 5 cols on lg */}
              <div className="lg:col-span-5 space-y-4">
                <div className="bg-slate-100 dark:bg-slate-900/60 rounded-3xl p-6 border border-slate-200 dark:border-slate-800">
                  <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 mb-3 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-amber-500" /> Real vaqtda mini-ko'rinish
                  </h3>
                  
                  {/* Container designed to automatically measure and scale using CSS transform */}
                  <div 
                    ref={previewContainerRef}
                    className="w-full bg-slate-200 dark:bg-slate-950 rounded-2xl overflow-hidden p-3 flex justify-center items-center min-h-[220px]"
                  >
                    <div 
                      style={{ 
                        transform: `scale(${scaleFactor * 0.45})`, 
                        transformOrigin: "center center" 
                      }}
                      className="shrink-0 transition-transform duration-200"
                    >
                      <DocumentTemplate
                        id="form-live-preview-widget"
                        type={selectedType}
                        style={designStyle}
                        variant={variant}
                        recipientName={recipientName || "[Ism Familiya]"}
                        topic={topic || "[Mavzu yo'nalishi yoki yutuq sababi]"}
                        teacherName={teacherName || "[Ustoz ismi]"}
                        parentName={parentName || "[Ota-ona ismi]"}
                        reason={reason}
                        signatureImage={signatureImage}
                        date={customDate}
                        serialNumber={serialNumber}
                        badgeType={badgeType}
                        showQrCode={showQrCode}
                        qrCodeUrl={qrCodeUrl.trim() || (typeof window !== "undefined" ? window.location.href : "")}
                      />
                    </div>
                  </div>
                  
                  <p className="text-[11px] text-slate-500 text-center mt-3">
                    Har bir o'zgarish, tanlangan variant va muhrlar bu yerda bir zumda aks etadi!
                  </p>
                </div>

                <div className="bg-gradient-to-tr from-amber-500/5 to-indigo-500/5 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 text-center space-y-3">
                  <span className="text-2xl">⚡</span>
                  <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 font-classic">Sonsiz Variatsiyalar</h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                    Siz hamma narsani to'liq tahrirlashingiz mumkin. Bitta uslub bilan cheklanib qolmang - tilla muhr, kiberneon nurlari yoki dabdabali klassika o'rtasida osonlik bilan o'ting!
                  </p>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* SCREEN C: RESULT VIEW & EXPORTER */}
        {currentScreen === "result" && generatedDoc && (
          <div className="space-y-8 animate-fade-in py-4">
            
            {/* Header toolbar */}
            <div className="no-print flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setCurrentScreen("form")}
                  className="p-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                  title="Tahrirlashga qaytish"
                >
                  <ChevronLeft className="w-5 h-5" /> Tahrirlash
                </button>
                <div>
                  <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white font-classic">
                    Hujjat Tayyor! 🎉
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    O'zgarishlarni darhol pastdagi boshqaruv paneli orqali real vaqtda sinab ko'rishingiz mumkin.
                  </p>
                </div>
              </div>

              {/* Category Pill */}
              <div className="self-start sm:self-center">
                <span className="inline-flex items-center gap-1 text-xs bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold px-3 py-1.5 rounded-full border border-indigo-200 dark:border-indigo-900">
                  {generatedDoc.type === "diploma" && "🏆 Diplom"}
                  {generatedDoc.type === "certificate" && "📜 Sertifikat"}
                  {generatedDoc.type === "gratitude" && "❤️ Ota-onaga tashakkurnoma"}
                </span>
              </div>
            </div>

            {/* Live customizer bar in Result Screen to change themes instantly on the fly */}
            <div className="no-print bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-4 shadow-sm">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                <span className="text-xs font-black text-slate-400 tracking-widest uppercase flex items-center gap-1.5">
                  <Palette className="w-4 h-4 text-amber-500" /> Instant Customizer:
                </span>
                
                {/* Instant Theme Selector Buttons */}
                <div className="flex flex-wrap gap-1.5">
                  {(["classic", "gold", "modern", "kids"] as DesignStyle[]).map((st) => (
                    <button
                      key={st}
                      onClick={() => handleCycleStyle(st)}
                      className={`text-xs px-2.5 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${designStyle === st ? "bg-amber-500 text-white shadow-xs" : "bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300"}`}
                    >
                      {st === "classic" && "Klassik"}
                      {st === "gold" && "Oltin"}
                      {st === "modern" && "Modern"}
                      {st === "kids" && "Bolalar"}
                    </button>
                  ))}
                </div>
              </div>

              {/* Variation cycler */}
              <button
                onClick={handleCycleVariant}
                className="w-full md:w-auto inline-flex items-center justify-center gap-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 px-4 py-2 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-700 transition-all cursor-pointer"
              >
                🔄 Dizayn variantini yangilash (<span className="text-amber-500">{variant}-variant</span>)
              </button>
            </div>

            {/* Document Render stage with responsive scaling wrapper */}
            <div className="no-print flex flex-col items-center justify-center space-y-4">
              <div 
                ref={previewContainerRef}
                className="w-full flex justify-center bg-slate-200/50 dark:bg-slate-950/40 p-4 sm:p-8 rounded-3xl border border-slate-200 dark:border-slate-800/80 overflow-hidden"
              >
                {/* 
                  To ensure that the rendering looks identical on all devices, we display the natural 1000px x 707px sheet.
                  We use the calculated scale factor to cleanly scale down the certificate on smaller screen widths.
                */}
                <div 
                  style={{ 
                    transform: `scale(${scaleFactor})`, 
                    transformOrigin: "center center",
                    width: "1000px",
                    height: "707px"
                  }}
                  className="shrink-0 transition-all shadow-2xl rounded-sm overflow-hidden"
                >
                  <DocumentTemplate
                    id="preview-certificate-only"
                    type={generatedDoc.type}
                    style={generatedDoc.style}
                    variant={generatedDoc.variant}
                    recipientName={generatedDoc.recipientName}
                    topic={generatedDoc.topic}
                    teacherName={generatedDoc.teacherName}
                    parentName={generatedDoc.parentName}
                    reason={generatedDoc.reason}
                    signatureImage={generatedDoc.signatureImage}
                    date={generatedDoc.date}
                    serialNumber={generatedDoc.serialNumber}
                    badgeType={generatedDoc.badgeType}
                    showQrCode={generatedDoc.showQrCode}
                    qrCodeUrl={generatedDoc.qrCodeUrl}
                  />
                </div>
              </div>

              {/* Current layout label */}
              <p className="text-xs text-indigo-500 font-bold bg-indigo-50 dark:bg-indigo-950/40 px-3 py-1 rounded-full border border-indigo-200/30">
                Faol rang: {getVariantLabel(variant)}
              </p>

              {/* Helper text for print landscape */}
              <p className="text-xs text-slate-500 text-center flex items-center justify-center gap-1.5 bg-slate-100 dark:bg-slate-900/50 py-2 px-4 rounded-full max-w-xl border border-slate-200 dark:border-slate-800">
                <span>💡</span>
                <strong>Maslahat:</strong> Agar "Chop etish" tugmasini bossangiz, printer sozlamalaridan <strong>"Landscape" (Albom)</strong> yo'nalishini tanlang.
              </p>
            </div>

            {/* Hidden off-screen high-res target for print and download */}
            <div 
              id="print-download-container"
              className="absolute left-[-9999px] top-[-9999px] pointer-events-none"
              style={{ width: "1000px", height: "707px" }}
            >
              <DocumentTemplate
                id="print-certificate-target"
                type={generatedDoc.type}
                style={generatedDoc.style}
                variant={generatedDoc.variant}
                recipientName={generatedDoc.recipientName}
                topic={generatedDoc.topic}
                teacherName={generatedDoc.teacherName}
                parentName={generatedDoc.parentName}
                reason={generatedDoc.reason}
                signatureImage={generatedDoc.signatureImage}
                date={generatedDoc.date}
                serialNumber={generatedDoc.serialNumber}
                badgeType={generatedDoc.badgeType}
                showQrCode={generatedDoc.showQrCode}
                qrCodeUrl={generatedDoc.qrCodeUrl}
              />
            </div>

            {/* GORGEOUS DIALOG/MODAL FOR FALLBACK IMAGE SAVE */}
            {showSaveModal && downloadedImageUri && (
              <div className="no-print fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
                <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative border border-slate-200 dark:border-slate-800">
                  <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
                    <div className="flex items-center gap-2.5">
                      <span className="text-2xl">🎉</span>
                      <div>
                        <h3 className="text-lg font-black text-slate-900 dark:text-white font-classic">Hujjat Tayyor!</h3>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">Yuklab olish va saqlash oynasi</p>
                      </div>
                    </div>
                    <button
                      onClick={() => setShowSaveModal(false)}
                      className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer text-sm font-bold"
                    >
                      Yopish [X]
                    </button>
                  </div>

                  <div className="space-y-4">
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                      Sizning hujjatingiz muvaffaqiyatli tayyorlandi! Agar kompyuteringiz yoki telefoningizga yuklash avtomatik boshlanmagan bo'lsa, pastdagi rasmga <strong>sichqonchaning o'ng tugmasini bosib "Rasmni saqlash..."</strong> (Save image as...) ni tanlang yoki smartfonda rasm ustiga bosing va uzoq bosib turing:
                    </p>

                    {/* Image Preview inside modal */}
                    <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-md max-h-[300px] overflow-y-auto bg-slate-50">
                      <img 
                        src={downloadedImageUri} 
                        alt="Tayyor Hujjat" 
                        className="w-full h-auto object-contain"
                        referrerPolicy="no-referrer"
                      />
                    </div>

                    <div className="bg-amber-50 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900/40 rounded-2xl p-4 text-xs text-slate-600 dark:text-slate-300 flex items-start gap-2.5">
                      <span className="text-lg shrink-0 mt-0.5">💡</span>
                      <div className="space-y-1">
                        <p className="font-bold text-amber-800 dark:text-amber-400">Sayt mini-oynada (iFrame) ochilgan bo'lsa:</p>
                        <p>Sayt kichik ko'rinishda bo'lgani sababli brauzer avtomatik yuklashni cheklashi mumkin. To'liq chop etish va yuklab olish imkoniyatidan foydalanish uchun saytni yuqoridagi <strong>"New Tab" (Yangi Oyna)</strong> tugmasi orqali alohida oynada ochishni tavsiya etamiz.</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-end pt-2">
                    <button
                      onClick={() => setShowSaveModal(false)}
                      className="bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold px-6 py-2.5 rounded-xl text-xs hover:bg-slate-800 dark:hover:bg-slate-100 transition-colors cursor-pointer"
                    >
                      Tushunarli, yopish
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Action Buttons Toolbar at bottom */}
            <div className="no-print pt-6 flex flex-col sm:flex-row items-center justify-center gap-4 border-t border-slate-200 dark:border-slate-800">
              
              {/* PRINT BUTTON */}
              <button
                onClick={handlePrint}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 font-extrabold px-6 py-3.5 rounded-2xl shadow-md transition-all text-sm cursor-pointer"
              >
                <Printer className="w-4 h-4" /> 🖨 Chop etish (PDF)
              </button>

              {/* DOWNLOAD HIGH-RESOLUTION PNG */}
              <button
                onClick={handleDownload}
                disabled={isDownloading}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-extrabold px-6 py-3.5 rounded-2xl shadow-md shadow-amber-500/10 transition-all text-sm disabled:opacity-50 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                {isDownloading ? "Yuklanmoqda..." : "⬇ Tasvirni yuklab olish (PNG)"}
              </button>

              {/* RE-CREATE BUTTON */}
              <button
                onClick={handleRestart}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-white hover:bg-slate-50 dark:bg-slate-900 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 font-extrabold px-6 py-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm transition-all text-sm cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" /> 🔄 Yangi yaratish
              </button>

            </div>

          </div>
        )}

      </main>

      {/* FOOTER BAR */}
      <footer className="no-print bg-white dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 py-6 mt-12 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4 text-center">
          <div className="flex flex-col md:flex-row items-center gap-2 md:gap-4 text-xs text-slate-500 dark:text-slate-400">
            <p>
              &copy; {new Date().getFullYear()} <strong>DiplomaAI</strong> — Muhammadaziz Rustamov loyihasi. Barcha huquqlar himoyalangan.
            </p>
            <span className="hidden md:inline text-slate-300 dark:text-slate-800">|</span>
            <a 
              href="https://men-haqqimdaaa.vercel.app/" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="text-indigo-600 dark:text-indigo-400 hover:underline font-bold transition-all"
            >
              Asoschi haqida bilib oling
            </a>
          </div>
          <div className="flex gap-4 text-xs text-slate-400 dark:text-slate-500">
            <span className="cursor-default">Klassik</span>
            <span className="text-slate-300 dark:text-slate-800">|</span>
            <span className="cursor-default">Zamonaviy</span>
            <span className="text-slate-300 dark:text-slate-800">|</span>
            <span className="cursor-default">Qirollik Oltini</span>
            <span className="text-slate-300 dark:text-slate-800">|</span>
            <span className="cursor-default">Bolalar uchun</span>
          </div>
        </div>
      </footer>

      {/* FLOATING MUSIC PLAYER */}
      <div className="no-print fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3">
        {/* Expanded Music Player Panel */}
        {showPlayerPanel && (
          <div className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-xl border border-slate-200/60 dark:border-slate-800/60 rounded-3xl p-5 shadow-2xl w-80 transition-all duration-300 animate-slide-up text-slate-800 dark:text-slate-100">
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Music className="w-5 h-5 text-amber-500 animate-pulse" />
                <span className="font-extrabold text-sm tracking-tight text-slate-900 dark:text-white">
                  Musiqa & Atmosfera
                </span>
              </div>
              <button 
                onClick={() => setShowPlayerPanel(false)}
                className="text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300 text-xs px-2 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                Yopish
              </button>
            </div>

            {/* Current Track Info */}
            <div className="bg-slate-50 dark:bg-slate-950/50 border border-slate-100 dark:border-slate-800/50 rounded-2xl p-3 mb-4 flex items-center gap-3">
              <div className="w-10 h-10 bg-amber-500/10 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400 rounded-xl flex items-center justify-center font-bold">
                {isPlaying ? (
                  <div className="flex items-end gap-0.5 h-4">
                    <div className="w-0.5 bg-amber-500 rounded-full equalizer-bar-1" />
                    <div className="w-0.5 bg-amber-500 rounded-full equalizer-bar-2" />
                    <div className="w-0.5 bg-amber-500 rounded-full equalizer-bar-3" />
                    <div className="w-0.5 bg-amber-500 rounded-full equalizer-bar-4" />
                  </div>
                ) : (
                  <Music className="w-5 h-5" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[10px] uppercase tracking-wider font-extrabold text-amber-500">
                  Hozir ijroda
                </p>
                <p className="text-xs font-bold truncate text-slate-800 dark:text-slate-200">
                  {tracks[currentTrackIndex].name}
                </p>
              </div>
            </div>

            {/* Track Selector List */}
            <div className="space-y-1 mb-4 max-h-32 overflow-y-auto pr-1">
              {tracks.map((track, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setCurrentTrackIndex(idx);
                    setIsPlaying(true);
                  }}
                  className={`w-full text-left text-xs px-3 py-2 rounded-xl flex items-center justify-between transition-colors ${
                    currentTrackIndex === idx
                      ? "bg-amber-50 dark:bg-amber-950/25 text-amber-700 dark:text-amber-300 font-bold border border-amber-200/50 dark:border-amber-900/50"
                      : "hover:bg-slate-50 dark:hover:bg-slate-800/40 text-slate-600 dark:text-slate-400 border border-transparent"
                  }`}
                >
                  <span className="truncate">{track.name}</span>
                  {currentTrackIndex === idx && isPlaying && (
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping" />
                  )}
                </button>
              ))}
            </div>

            {/* Controls */}
            <div className="flex items-center justify-between gap-4 border-t border-slate-100 dark:border-slate-800/60 pt-4">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="w-10 h-10 bg-amber-500 hover:bg-amber-600 text-white rounded-full flex items-center justify-center transition-transform active:scale-95 shadow-md shadow-amber-500/20 cursor-pointer"
                >
                  {isPlaying ? (
                    <Pause className="w-5 h-5 fill-white text-white" />
                  ) : (
                    <Play className="w-5 h-5 fill-white text-white translate-x-0.5" />
                  )}
                </button>
                <button
                  onClick={() => setCurrentTrackIndex((prev) => (prev + 1) % tracks.length)}
                  title="Keyingi musiqa"
                  className="w-8 h-8 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-full flex items-center justify-center transition-colors cursor-pointer"
                >
                  <SkipForward className="w-4 h-4" />
                </button>
              </div>

              {/* Volume */}
              <div className="flex items-center gap-2 flex-1 max-w-[120px]">
                <button
                  onClick={() => setIsMuted(!isMuted)}
                  className="text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300 transition-colors"
                >
                  {isMuted || volume === 0 ? (
                    <VolumeX className="w-4 h-4" />
                  ) : (
                    <Volume2 className="w-4 h-4" />
                  )}
                </button>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={isMuted ? 0 : volume}
                  onChange={(e) => {
                    setVolume(parseFloat(e.target.value));
                    if (isMuted) setIsMuted(false);
                  }}
                  className="w-full h-1 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
                />
              </div>
            </div>
          </div>
        )}

        {/* GORGEOUS DIALOG/MODAL FOR MOBILE APP QR CODE */}
        {showQrModal && (
          <div className="no-print fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
            <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 sm:p-8 space-y-6 shadow-2xl relative border border-slate-200 dark:border-slate-800">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 bg-amber-500/10 border border-amber-500/30 rounded-full flex items-center justify-center">
                    <QrCode className="w-5 h-5 text-amber-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-slate-900 dark:text-white font-classic">Mobil ilova & QR Kod</h3>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">Telefon orqali ishlatish va yuklash</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowQrModal(false)}
                  className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer text-xs font-bold"
                >
                  Yopish [X]
                </button>
              </div>

              <div className="space-y-4 text-center">
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed text-left">
                  Ushbu ajoyib loyihani mobil telefoningizda ishlatish yoki uni telefonga yuklab olish (bosh ekranga joylash) uchun pastdagi QR kodni telefoningiz kamerasi orqali skaner qiling:
                </p>

                {/* QR Code Graphic container */}
                <div className="relative inline-block p-4 bg-white border-4 border-amber-500/20 rounded-2xl shadow-inner mx-auto">
                  <img 
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(typeof window !== "undefined" ? window.location.href : "https://ais-pre-kq3tnlurwccjmv5wskt6dv-276889638275.asia-southeast1.run.app")}`} 
                    alt="DiplomaAI App QR Code" 
                    className="w-48 h-48 object-contain"
                    referrerPolicy="no-referrer"
                    crossOrigin="anonymous"
                  />
                  {/* Pulse Scanline element for visual design */}
                  <div className="absolute top-4 left-4 right-4 h-0.5 bg-amber-500/70 shadow-sm animate-pulse-line"></div>
                </div>

                <p className="text-[11px] font-mono font-bold text-amber-600 dark:text-amber-400 truncate">
                  {typeof window !== "undefined" ? window.location.href : "https://ais-pre-kq3tnlurwccjmv5wskt6dv-276889638275.asia-southeast1.run.app"}
                </p>

                {/* Quick Instructions list */}
                <div className="text-left bg-slate-50 dark:bg-slate-800/50 rounded-2xl p-4 space-y-2 border border-slate-100 dark:border-slate-800">
                  <p className="text-xs font-bold text-slate-800 dark:text-slate-200">📲 Qanday yuklab olinadi va ishlatiladi?</p>
                  <ol className="list-decimal list-inside text-[10px] text-slate-500 dark:text-slate-400 space-y-1.5 leading-relaxed font-medium">
                    <li>Kamerangizni QR kodga qarating va chiqqan havolaga bosing.</li>
                    <li><strong>Androidda:</strong> Brauzer menyusidan <strong className="text-slate-700 dark:text-slate-200">"Add to Home Screen" (Ilovani o'rnatish)</strong> tugmasini tanlang.</li>
                    <li><strong>iPhoneda (iOS):</strong> Pastdagi <strong className="text-slate-700 dark:text-slate-200">"Ulashish" (Share)</strong> tugmasini bosib, <strong className="text-slate-700 dark:text-slate-200">"Add to Home Screen" (Bosh ekranga qo'shish)</strong>ni tanlang.</li>
                    <li>Endi loyihadan istalgan vaqtda xuddi mustaqil mobil ilovadek tez va oson foydalanishingiz mumkin!</li>
                  </ol>
                </div>

                {/* QR Download option */}
                <div className="flex gap-2 pt-2">
                  <a
                    href={`https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${encodeURIComponent(typeof window !== "undefined" ? window.location.href : "https://ais-pre-kq3tnlurwccjmv5wskt6dv-276889638275.asia-southeast1.run.app")}`}
                    target="_blank"
                    rel="noreferrer"
                    className="w-full inline-flex items-center justify-center gap-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold px-4 py-2.5 rounded-xl text-xs transition-colors cursor-pointer border border-slate-200 dark:border-slate-700"
                  >
                    <Download className="w-3.5 h-3.5" /> QR tasvirini ochish
                  </a>
                  <button
                    onClick={() => setShowQrModal(false)}
                    className="w-full bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold px-4 py-2.5 rounded-xl text-xs hover:bg-slate-800 dark:hover:bg-slate-100 transition-colors cursor-pointer"
                  >
                    Tushunarli
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Floating Player Button */}
        <button
          onClick={() => setShowPlayerPanel(!showPlayerPanel)}
          className={`group flex items-center gap-2 p-3.5 rounded-full shadow-2xl transition-all duration-300 cursor-pointer border ${
            isPlaying 
              ? "bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white border-amber-400/20" 
              : "bg-white hover:bg-slate-50 dark:bg-slate-900 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800"
          }`}
        >
          {isPlaying ? (
            <div className="flex items-end gap-0.5 h-3">
              <div className="w-0.5 bg-white rounded-full equalizer-bar-1" />
              <div className="w-0.5 bg-white rounded-full equalizer-bar-2" />
              <div className="w-0.5 bg-white rounded-full equalizer-bar-3" />
            </div>
          ) : (
            <Music className="w-4 h-4 group-hover:rotate-12 transition-transform" />
          )}
          <span className="text-xs font-extrabold pr-1">
            {isPlaying ? "Musiqa ijroda" : "Musiqa qo'shish"}
          </span>
        </button>
      </div>

    </div>
  );
}
